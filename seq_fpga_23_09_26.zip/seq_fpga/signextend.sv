module signextend   #(parameter IN_WIDTH, parameter OUT_WIDTH)

(  input logic signed [IN_WIDTH-1:0] in,
   output logic signed [OUT_WIDTH-1:0] out);

genvar i;

generate 
	for(i=IN_WIDTH-1; i<OUT_WIDTH; i=i+1) begin : connect
		assign out[i] =  in[IN_WIDTH-1];
	end
endgenerate

assign out[IN_WIDTH-2:0] = in[IN_WIDTH-2:0];

	
endmodule