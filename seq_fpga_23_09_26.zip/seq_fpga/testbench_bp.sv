module testbench_bp

`timescale 1ns/100ps;

logic CLK_10MHZ;
logic SAMPLE_FREQ;
logic [15:0] SHIFT_DATA_OUT_READY_U16;
logic DIN;
logic CLK_IN;
logic CLK_IN_BU;
logic MUX_DATA_IN_0_7;
logic MUX_DATA_IN_8_15;
logic [2:0] MUX_LINE;
logic BTN_DATA_OUT;
logic BTN_IRQ;



logic [7:0] BTN_PRESET_BANK_A = 8'b11111110;
logic [7:0] BTN_PRESET_BANK_B = 8'b10100001;

//internal signals

logic mux_data_sel;
logic[15:0] button_state_reg_init;
logic[15:0] button_state_reg_cmp;
logic scan_clk;
logic [4:0] scan_clk_ctr;
logic [3:0] data_out_ctr;
logic reset_out_ctr;

assign mux_data_sel = testbench_bp.dut.btn_unit_1.mux_data_sel;
assign button_state_reg_init = testbench_bp.dut.btn_unit_1.button_state_reg_init;
assign button_state_reg_cmp = testbench_bp.dut.btn_unit_1.button_state_reg_cmp;
assign scan_clk = testbench_bp.dut.btn_unit_1.SCAN_CLK;
assign scan_clk_ctr = testbench_bp.dut.btn_unit_1.scan_clk_ctr;
assign data_out_ctr = testbench_bp.dut.btn_unit_1.data_out_ctr;
assign reset_out_ctr = testbench_bp.dut.btn_unit_1.reset_out_ctr;

sequencer_dsp dut(.*);

mux_emu mux_1(.SEL(MUX_LINE),
				  .IN(BTN_PRESET_BANK_A),
				  .DOUT(MUX_DATA_IN_0_7));

mux_emu mux_2(.SEL(MUX_LINE),
				  .IN(BTN_PRESET_BANK_B),
				  .DOUT(MUX_DATA_IN_8_15));
				  
//simulates tx/rx between pico and fpga

always@(BTN_IRQ) 
begin
	CLK_IN_BU = 1'b0;
	#1us;
	for(int i = 0; i <16; i++) begin
	   CLK_IN_BU = 1'b0;
		#100ns;
		CLK_IN_BU = 1'b1;
		#100ns;
	end
	CLK_IN_BU = 1'b0;

end

//master clock

initial
begin
	CLK_10MHZ = 1'b0;
	forever #50 CLK_10MHZ = ~CLK_10MHZ;
end

initial
begin
	#121262000ps;
	BTN_PRESET_BANK_A = 8'b11101110;
end

initial 
begin
	#1ms;
	$finish;
end

endmodule