#include "math.h"
#include "stdio.h"
#include "stdlib.h"

extern void test(){
    printf("test");
}