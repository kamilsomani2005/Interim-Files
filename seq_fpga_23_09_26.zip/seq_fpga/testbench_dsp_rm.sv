`timescale 10ns/1ns

module testbench_dsp_rm;

logic signed [15:0] in;
logic [15:0] out;
logic clk;

localparam DEPTH_C1 = 1172;
localparam DEPTH_C2 = 1367;
localparam DEPTH_C3 = 1563;
localparam DEPTH_C4 = 1758;
localparam DEPTH_A1 = 260; //195->250 is a good choice
localparam DEPTH_A2 = 87;
localparam DEPTH_A3 = 29;

logic signed [19:0] probe_out_c1;
logic signed [19:0] probe_out_c2;
logic signed [19:0] probe_out_c3;
logic signed [19:0] probe_out_c4;

logic waveclk;
logic waveout;


reverb #(.DEPTH_C1(DEPTH_C1), .DEPTH_C2(DEPTH_C2), .DEPTH_C3(DEPTH_C3), .DEPTH_C4(DEPTH_C4), .DEPTH_A1(DEPTH_A1), .DEPTH_A2(DEPTH_A2), .DEPTH_A3(DEPTH_A3)) dut (.in(in), .out(out), .clk(clk));

									 
initial
begin
	int i;
	for(i=0; i<DEPTH_C1; i=i+1) begin
		testbench_dsp_rm.dut.c1.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_C2; i=i+1) begin
		testbench_dsp_rm.dut.c2.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_C3; i=i+1) begin
		testbench_dsp_rm.dut.c3.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_C4; i=i+1) begin
		testbench_dsp_rm.dut.c4.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_A1; i=i+1) begin
		testbench_dsp_rm.dut.ap1.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_A2; i=i+1) begin
		testbench_dsp_rm.dut.ap2.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_A3; i=i+1) begin
		testbench_dsp_rm.dut.ap3.d1.shift16ts[i] = 0;
	end
	testbench_dsp_rm.dut.synchdelay.shift16ts[0] = 0;
end

initial
begin
	clk = 1'b0;
	forever #12800ns clk = ~clk;
end

initial
begin
	waveout = 1'b1;
	waveclk = 1'b0;
	forever #10ms waveclk = ~waveclk;
end


initial 
begin
	in = 32767;         
	#25600ns in = 0;
	#2000ms;
	$finish;
end

initial begin
	#500ms;
	waveout = 1'b0;
end

/*
always @(waveclk) begin
	if(waveout) begin
		if(waveclk == 1'b0) begin
			in = -16384;
		end
		if(waveclk == 1'b1) begin
			in = 16384;
		end
	end else begin
		in = 0;
	end
end
*/


	

assign probe_out_c1 = testbench_dsp_rm.dut.c1.delay_to_gain;
assign probe_out_c2 = testbench_dsp_rm.dut.c2.delay_to_gain;
assign probe_out_c3 = testbench_dsp_rm.dut.c3.delay_to_gain;
assign probe_out_c4 = testbench_dsp_rm.dut.c4.delay_to_gain;


endmodule