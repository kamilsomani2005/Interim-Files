module multiplier #(parameter BITWIDTH)

(  input logic signed [BITWIDTH-1:0] in,
   input logic signed [BITWIDTH-1:0] gain,
   output logic signed [BITWIDTH-1:0] out);
	
logic signed [(BITWIDTH*2)-1:0] temp;

assign temp = in * gain;
assign out = temp[30+(BITWIDTH-16):15] + temp[(BITWIDTH*2)-2] + temp[14]; //rounding attempt




endmodule