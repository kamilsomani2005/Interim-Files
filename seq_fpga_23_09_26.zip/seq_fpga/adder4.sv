module adder4  #( parameter IN_WIDTH  = 20, parameter OUT_WIDTH = 22)

( input logic signed [IN_WIDTH-1:0] in1,
  input logic signed [IN_WIDTH-1:0] in2,
  input logic signed [IN_WIDTH-1:0] in3,
  input logic signed [IN_WIDTH-1:0] in4,
  output logic signed [OUT_WIDTH-1:0] out);
  
logic signed [OUT_WIDTH-1:0] in1sxtd;
logic signed [OUT_WIDTH-1:0] in2sxtd;
logic signed [OUT_WIDTH-1:0] in3sxtd;
logic signed [OUT_WIDTH-1:0] in4sxtd;
  
signextend #(.IN_WIDTH(IN_WIDTH), .OUT_WIDTH(OUT_WIDTH)) in1se 
						(.in(in1), .out(in1sxtd));
						
signextend #(.IN_WIDTH(IN_WIDTH), .OUT_WIDTH(OUT_WIDTH)) in2se 
						(.in(in2), .out(in2sxtd));

signextend #(.IN_WIDTH(IN_WIDTH), .OUT_WIDTH(OUT_WIDTH)) in3se
						(.in(in3), .out(in3sxtd));

signextend #(.IN_WIDTH(IN_WIDTH), .OUT_WIDTH(OUT_WIDTH)) in4se
						(.in(in4), .out(in4sxtd));

assign out = in1sxtd + in2sxtd + in3sxtd + in4sxtd;

endmodule