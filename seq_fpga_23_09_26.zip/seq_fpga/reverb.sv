module reverb #(parameter DEPTH_C1, parameter DEPTH_C2, parameter DEPTH_C3, parameter DEPTH_C4, parameter DEPTH_A1, parameter DEPTH_A2, parameter DEPTH_A3)

( input logic signed [15:0] in,
  output logic [15:0] out,
  input logic clk);
  
localparam COMBS_BITWIDTH = 20;
localparam ORIG_BITWIDTH = 16;
localparam AP_BITWIDTH = 25;
localparam COMBS_OUT_BITWIDTH = 22;
  
logic signed [COMBS_BITWIDTH-1:0] signextend_to_combs;
logic signed [AP_BITWIDTH-1:0] in_to_outmixer;
logic signed [COMBS_OUT_BITWIDTH-1:0] adder4_to_signextend2;
logic signed [ORIG_BITWIDTH-1:0] delay_to_signextend;
logic signed [AP_BITWIDTH-1:0] signextend2_to_allpass1;
logic signed [AP_BITWIDTH-1:0] allpass1_to_allpass2;
logic signed [AP_BITWIDTH-1:0] allpass2_to_allpass3;
logic signed [AP_BITWIDTH-1:0] ap_out_to_scaledown;
logic signed [AP_BITWIDTH-1:0] scaledown_to_outmixer;
logic signed [AP_BITWIDTH-1:0] outmixer_to_clipper;
logic signed [AP_BITWIDTH-1:0] clipper_to_positivizer;
logic signed [AP_BITWIDTH-1:0] ap_bw_out;
logic signed [COMBS_BITWIDTH-1:0] c1_to_add4;
logic signed [COMBS_BITWIDTH-1:0] c2_to_add4;
logic signed [COMBS_BITWIDTH-1:0] c3_to_add4;
logic signed [COMBS_BITWIDTH-1:0] c4_to_add4;

delay #(.DEPTH(1), .BITWIDTH(ORIG_BITWIDTH)) synchdelay
		 (.in(in), .clk(clk), .out(delay_to_signextend));
  
signextend #(.IN_WIDTH(ORIG_BITWIDTH), .OUT_WIDTH(COMBS_BITWIDTH)) s1in
				(.in(delay_to_signextend), .out(signextend_to_combs));
				
signextend #(.IN_WIDTH(ORIG_BITWIDTH), .OUT_WIDTH(AP_BITWIDTH)) s1in_to_outmixer
				(.in(delay_to_signextend), .out(in_to_outmixer));

combfilter #(.DEPTH(DEPTH_C1), .BITWIDTH(COMBS_BITWIDTH)) c1
				(.in(signextend_to_combs), .gain(20'd26635), .clk(clk), .out(c1_to_add4));
				
combfilter #(.DEPTH(DEPTH_C2), .BITWIDTH(COMBS_BITWIDTH)) c2
				(.in(signextend_to_combs), .gain(20'd25731), .clk(clk), .out(c2_to_add4));
				
combfilter #(.DEPTH(DEPTH_C3), .BITWIDTH(COMBS_BITWIDTH)) c3
				(.in(signextend_to_combs), .gain(20'd24857), .clk(clk), .out(c3_to_add4));
				
combfilter #(.DEPTH(DEPTH_C4), .BITWIDTH(COMBS_BITWIDTH)) c4
				(.in(signextend_to_combs), .gain(20'd24013), .clk(clk), .out(c4_to_add4));
				
adder4 a1 (.in1(c1_to_add4), .in2(c2_to_add4), .in3(c3_to_add4), .in4(c4_to_add4), .out(adder4_to_signextend2));

signextend #(.IN_WIDTH(COMBS_OUT_BITWIDTH), .OUT_WIDTH(AP_BITWIDTH)) s2c2ap
            (.in(adder4_to_signextend2), .out(signextend2_to_allpass1));
				
allpass #(.DEPTH(DEPTH_A1), .BITWIDTH(AP_BITWIDTH)) ap1
			(.in(signextend2_to_allpass1), .gain(25'd22938), .clk(clk), .out(allpass1_to_allpass2));  //22938 default (0.7)
			
allpass #(.DEPTH(DEPTH_A2), .BITWIDTH(AP_BITWIDTH)) ap2
			(.in(allpass1_to_allpass2), .gain(25'd22938), .clk(clk), .out(allpass2_to_allpass3));  //22938 default (0.7
			
allpass #(.DEPTH(DEPTH_A3), .BITWIDTH(AP_BITWIDTH)) ap3
			(.in(allpass2_to_allpass3), .gain(25'd22938), .clk(clk), .out(ap_out_to_scaledown));                      //22938 default (0.7)

multiplier #(.BITWIDTH(AP_BITWIDTH)) scaledown
			(.in(ap_out_to_scaledown), .gain(25'd32768), .out(scaledown_to_outmixer)); //change gain here for wet amnt    default = 25'd2500
			
adder #(.BITWIDTH(AP_BITWIDTH)) outmixer
			(.in_1(scaledown_to_outmixer), .in_2(in_to_outmixer), .out(outmixer_to_clipper));
			
clipper cl1 (.in(outmixer_to_clipper), .out(clipper_to_positivizer));
			
adder #(.BITWIDTH(AP_BITWIDTH)) positivizer
			(.in_1(clipper_to_positivizer), .in_2(25'd32768), .out(ap_bw_out));
			
assign out = ap_bw_out[15:0];
			
endmodule