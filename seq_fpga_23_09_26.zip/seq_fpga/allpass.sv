module allpass #(parameter DEPTH, parameter 	BITWIDTH)

( input logic signed [BITWIDTH-1:0] in,
  input logic clk,
  output logic signed [BITWIDTH-1:0] out,
  input logic signed [BITWIDTH-1:0] gain);
  
logic signed [BITWIDTH-1:0] pgain_to_adder;
logic signed [BITWIDTH-1:0] adder_to_ngain_delay;
logic signed [BITWIDTH-1:0] delay_to_pgain_oadder;
logic signed [BITWIDTH-1:0] ngain_to_oadder;

adder #(.BITWIDTH(BITWIDTH)) a1
		 (.in_1(in), .in_2(pgain_to_adder), .out(adder_to_ngain_delay));
		 
delay #(.DEPTH(DEPTH), .BITWIDTH(BITWIDTH)) d1
	    (.in(adder_to_ngain_delay), .clk(clk), .out(delay_to_pgain_oadder));
		 
multiplier #(.BITWIDTH(BITWIDTH)) m1 
				(.in(delay_to_pgain_oadder), .gain(gain), .out(pgain_to_adder));
				
multiplier #(.BITWIDTH(BITWIDTH)) m2
            (.in(adder_to_ngain_delay), .gain(-gain), .out(ngain_to_oadder));
				
adder #(.BITWIDTH(BITWIDTH)) a2
		 (.in_1(ngain_to_oadder), .in_2(delay_to_pgain_oadder), .out(out));

endmodule