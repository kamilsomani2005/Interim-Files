module sequencer_dsp

(  input logic CLK_10MHZ,
	output logic SAMPLE_FREQ,
	output logic N_CS,
	output logic SDO,
	output logic SCLK,
	input logic DIN,
	input logic CLK_IN,
	output logic [9:0] LEDR = '0);
	

logic [7:0] div_by_2e8 = 8'b00000000;
logic signed [15:0] parallel_data_in_s16;
logic [15:0] parallel_data_out_u16;

always @(posedge CLK_10MHZ)
begin
		div_by_2e8 <= div_by_2e8 + 1;
end

assign SAMPLE_FREQ = div_by_2e8[7];

sample_comms comms_1(.SAMPLE_FREQ(SAMPLE_FREQ),
							.shift_data_out_ready_u16(parallel_data_in_s16),
							.DIN(DIN),
							.CLK_IN(CLK_IN));
							
spi_dac dac_1(.parallel_data_rdy_u16(parallel_data_out_u16),
				  .SAMPLE_FREQ(SAMPLE_FREQ),
				  .CLK_10MHZ(CLK_10MHZ),
				  .SCLK(SCLK),
				  .SDO(SDO),
				  .N_CS(N_CS));
				  
reverb  #(.DEPTH_C1(1172), .DEPTH_C2(1367), .DEPTH_C3(1563), .DEPTH_C4(1758), .DEPTH_A1(260), .DEPTH_A2(87), .DEPTH_A3(29)) rm (.in(parallel_data_in_s16), .clk(SAMPLE_FREQ), .out(parallel_data_out_u16));	//fix instantiation					 

endmodule