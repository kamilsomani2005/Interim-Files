module delay #(parameter DEPTH, parameter BITWIDTH)

(  input logic signed [BITWIDTH-1:0] in,
	input logic clk,
   output logic signed [BITWIDTH-1:0] out);
	
logic signed [(DEPTH-1):0][BITWIDTH-1:0] shift16ts; 

int i;
always_ff @(posedge clk) begin
   //out <= shift16ts[DEPTH-1];
	for (i=(DEPTH-1); i>0; i=i-1) begin
		shift16ts[i] <= shift16ts[i-1];
	end
	shift16ts[0] <= in;
end

assign out = shift16ts[DEPTH-1];

endmodule