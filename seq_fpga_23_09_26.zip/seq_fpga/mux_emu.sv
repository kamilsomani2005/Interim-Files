module mux_emu

(  input logic [2:0] SEL,
	input logic [7:0] IN,
	output logic DOUT);
	
always_comb begin

	DOUT = IN[SEL];

end

endmodule