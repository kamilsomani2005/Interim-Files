module test_pico

( input logic CLK_IN,
  output logic CLK_OUT,
  output logic DATA);
  
logic pio_clk_gen;
logic [3:0] data_cnt;
logic stream_en;
logic [15:0] payload_reg = 16'b1011101010100000;
  
always@(posedge CLK_IN)
begin
		stream_en <= 1'b1;
end

always_comb
begin
		CLK_OUT = stream_en && pio_clk_gen;
		DATA = payload_reg[data_cnt];
end
  
always@(posedge CLK_OUT)
begin
	if(data_cnt == 4'b1111) begin
		stream_en <= 1'b0;
		data_cnt <= 4'b0;
	end
	else begin
		data_cnt <= data_cnt + 1;
	end
end
 

endmodule