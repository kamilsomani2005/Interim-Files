module combfilter #(parameter DEPTH, parameter BITWIDTH)

(  input logic signed [BITWIDTH-1:0] in,
	input logic signed [BITWIDTH-1:0] gain,
	input logic clk,
   output logic signed [BITWIDTH-1:0] out);
	
logic signed [BITWIDTH-1:0] gain_to_adder;
logic signed [BITWIDTH-1:0] adder_to_delay;
logic signed [BITWIDTH-1:0] delay_to_gain;
	
adder #(.BITWIDTH(BITWIDTH)) a1 (.in_1(in),
			.in_2(gain_to_adder),
			.out(adder_to_delay));
	
delay #(.DEPTH(DEPTH), .BITWIDTH(BITWIDTH)) d1( .in(adder_to_delay),
									.clk(clk),
									.out(out));
			
	
multiplier #(.BITWIDTH(BITWIDTH)) m1 (.in(delay_to_gain),
				  .gain(gain),
				  .out(gain_to_adder));
				  
assign delay_to_gain = out;
				  
endmodule