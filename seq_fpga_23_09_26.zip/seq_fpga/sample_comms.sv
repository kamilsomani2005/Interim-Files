module sample_comms

(  input logic SAMPLE_FREQ,
	output logic signed [15:0] shift_data_out_ready_u16,
	input logic DIN,
	input logic CLK_IN);

logic [15:0] shift_data_in_u16;
logic [3:0] bit_index_ctr = 4'b0000;

always @(posedge CLK_IN) begin
	bit_index_ctr <= bit_index_ctr + 1;
	shift_data_in_u16[bit_index_ctr] <= DIN;
end

always @(posedge SAMPLE_FREQ) begin
	shift_data_out_ready_u16 <= shift_data_in_u16;
end

endmodule