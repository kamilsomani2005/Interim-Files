module adder #(parameter BITWIDTH)

(  input logic signed [BITWIDTH-1:0] in_1,
   input logic signed [BITWIDTH-1:0] in_2,
   output logic signed [BITWIDTH-1:0] out);
	
       
assign out = in_1 + in_2;


endmodule