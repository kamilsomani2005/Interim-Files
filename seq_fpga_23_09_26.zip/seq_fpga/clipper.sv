module clipper

( input logic signed [24:0] in,
  output logic signed [24:0] out);
  
always_comb begin
	if(in > 32767) begin
		out = 32767;
	end 
	else if (in < -32768) begin
		out = -32767;
	end
	else begin
		out = in;
	end
end




endmodule