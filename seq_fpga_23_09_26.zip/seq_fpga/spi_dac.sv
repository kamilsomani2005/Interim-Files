module spi_dac

(	input logic [15:0] parallel_data_rdy_u16,
	input logic SAMPLE_FREQ,
	input logic CLK_10MHZ,
	output logic SCLK,
	output logic SDO,
	output logic N_CS);
	
logic [3:0] mux_4 = 4'b1111;
logic decr_enab;

always_comb 
begin
	SDO = parallel_data_rdy_u16[mux_4];
	N_CS = ~SAMPLE_FREQ;
end

enum bit[1:0] {idle, dout, rst_clk, wait_for_n_cs} present_state, next_state;

always@(posedge CLK_10MHZ)
begin
	present_state <= next_state;
	if(N_CS) begin
		mux_4 <= 4'b1111;
	end else if (SCLK) begin
		mux_4 <= mux_4 - 1'b1;
	end
end

always_comb
begin
	SCLK = 1'b0;
	decr_enab = 1'b0;
	case (present_state)
		idle: begin
				SCLK = 1'b0;
				decr_enab = 1'b0;
				if(SAMPLE_FREQ) begin
					next_state = dout;
				end else begin
					next_state = idle;
				end
		end
		dout: begin
				SCLK = 1'b1;
				decr_enab = 1'b0;
				next_state = rst_clk;
		end
		rst_clk: begin
				SCLK = 1'b0;
				decr_enab = 1'b1;
				if(mux_4 == 4'b1111) begin
					next_state = wait_for_n_cs;
				end else begin
					next_state = dout;
				end
		end
		wait_for_n_cs: begin
				SCLK = 1'b0;
				decr_enab = 1'b0;
				if(N_CS) begin
					next_state = idle;
				end else begin
					next_state = wait_for_n_cs;
				end
		end
	endcase
end





endmodule