`timescale 10ns/1ns

module testbench_dsp_full;

localparam DEPTH_C1 = 1172;
localparam DEPTH_C2 = 1367;
localparam DEPTH_C3 = 1563;
localparam DEPTH_C4 = 1758;
localparam DEPTH_A1 = 260; //195->250 is a good choice
localparam DEPTH_A2 = 87;
localparam DEPTH_A3 = 29;

logic CLK_10MHZ;
logic SAMPLE_FREQ;
logic N_CS;
logic SDO;
logic SCLK;
logic DIN;
logic CLK_IN;
logic [9:0] LEDR;

logic [15:0] data;
logic [15:0] parallel_data_out_u16_probe;
logic signed [15:0] parallel_data_in_s16_probe;
int taskint = 0;

// #### TOP LEVEL MODULE INSTANTIATIONS & COMMS. ####

sequencer_dsp dut(.*);

initial
begin
	DIN = 1'b0;
	CLK_IN = 1'b0;
	CLK_10MHZ = 1'b0;
	forever #50ns CLK_10MHZ = ~CLK_10MHZ;
end


initial 
begin
	testbench_dsp_full.dut.div_by_2e8 = 8'b0;
	testbench_dsp_full.dut.comms_1.shift_data_out_ready_u16 = 16'b0;
end

initial 
begin
	#20ns
	for(int i = 0; i <16; i++) begin
	   CLK_IN = 1'b0;
		DIN = 1'b0;
		#10ns;
		CLK_IN = 1'b1;
		#10ns;
	end
end


task load_data (input logic [15:0] payload);
	
	CLK_IN = 1'b0;
	DIN = 1'b0;
	#1000ns;
	for(int i = 0; i <16; i++) begin
	   CLK_IN = 1'b0;
		DIN = payload[i];
		#100ns;
		CLK_IN = 1'b1;
		#100ns;
	end
	CLK_IN = 1'b0;
	DIN = 1'b0;

endtask : load_data

always@(posedge SAMPLE_FREQ) begin
	
	taskint++;
	if(taskint == 1) begin
		load_data(.payload(16'b0111111111111111));
	end else begin
		load_data(.payload(16'b0000000000000000));
	end
	
end


// #### REVERB MODULE INITIALISATIONS ####

									 
initial
begin
	int i;
	for(i=0; i<DEPTH_C1; i=i+1) begin
		testbench_dsp_full.dut.rm.c1.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_C2; i=i+1) begin
		testbench_dsp_full.dut.rm.c2.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_C3; i=i+1) begin
		testbench_dsp_full.dut.rm.c3.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_C4; i=i+1) begin
		testbench_dsp_full.dut.rm.c4.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_A1; i=i+1) begin
		testbench_dsp_full.dut.rm.ap1.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_A2; i=i+1) begin
		testbench_dsp_full.dut.rm.ap2.d1.shift16ts[i] = 0;
	end
	for(i=0; i<=DEPTH_A3; i=i+1) begin
		testbench_dsp_full.dut.rm.ap3.d1.shift16ts[i] = 0;
	end
	testbench_dsp_full.dut.rm.synchdelay.shift16ts[0] = 0;
end


initial 
begin
	#1000ms;
	$finish;
end

assign parallel_data_out_u16_probe = testbench_dsp_full.dut.parallel_data_out_u16;
assign parallel_data_in_s16_probe = testbench_dsp_full.dut.parallel_data_in_s16;


endmodule