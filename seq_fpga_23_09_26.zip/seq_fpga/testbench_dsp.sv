`timescale 10ns/1ns

module testbench_dsp;

localparam initialbitwidth = 20;

logic signed [initialbitwidth-1:0] in;
logic signed [initialbitwidth-1:0] gain;
logic signed [initialbitwidth-1:0] out;
logic clk;

logic signed [initialbitwidth-1:0] gain_to_adder_probe;
logic signed [initialbitwidth-1:0] adder_to_delay_probe;
logic signed [initialbitwidth-1:0] delay_to_gain_probe;

logic signed [15:0] test_signed_input;
logic signed [19:0] test_signed_output;

localparam c1depth = 4;

combfilter #(.DEPTH(c1depth), .BITWIDTH(initialbitwidth)) c1 (.in(in),
									 .gain(gain),
									 .clk(clk),
									 .out(out));
									 
signextend #(.IN_WIDTH(16), .OUT_WIDTH(20)) se1
									(.in(test_signed_input),
									 .out(test_signed_output));


									 
initial
begin
	int i;
	for(i=0; i<c1depth; i=i+1) begin
		testbench_dsp.c1.d1.shift16ts[i] = 0;
	end
end


initial
begin
	clk = 1'b0;
	forever #50 clk = ~clk;
end


initial 
begin
	in = -32767;
	gain = 16384;
	test_signed_input = 50;
	#100 test_signed_input = -50;
	#20000ns;
	$finish;
end

assign gain_to_adder_probe = testbench_dsp.c1.gain_to_adder;
assign adder_to_delay_probe = testbench_dsp.c1.adder_to_delay;
assign delay_to_gain_probe = testbench_dsp.c1.delay_to_gain;

endmodule