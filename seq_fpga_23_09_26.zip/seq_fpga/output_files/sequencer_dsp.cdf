/* Quartus Prime Version 22.1std.2 Build 922 07/20/2023 SC Standard Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Ign)
		Device PartName(10M50DAF484) MfrSpec(OpMask(0) Child_OpMask(2 3 0) FullPath("I:/Y3/COMP3200/seq_fpga/output_files/sequencer_dsp.pof"));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
