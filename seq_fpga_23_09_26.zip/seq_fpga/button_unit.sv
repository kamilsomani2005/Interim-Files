module button_unit

( input logic SCAN_CLK,
  input logic CLK_IN,
  output logic BTN_IRQ,
  output logic BTN_DATA_OUT,
  input logic MUX_DATA_IN_0_7,
  input logic MUX_DATA_IN_8_15,
  output logic [2:0] MUX_LINE);
  
logic[4:0] scan_clk_ctr = 5'b00000;
logic btn_irq_init_val = 1'b0;
logic[15:0] button_state_reg_init = 16'b0000000000000000;
logic[15:0] button_state_reg_cmp = 16'b0000000000000000;
logic mux_data_sel;
logic reset_out_ctr;
logic[3:0] data_out_ctr = 4'b0000;

assign MUX_LINE = scan_clk_ctr[2:0];
assign BTN_IRQ = btn_irq_init_val;
  
always@(posedge SCAN_CLK) 
begin
	if(scan_clk_ctr == 5'b10000) begin
		if(button_state_reg_cmp != button_state_reg_init) begin
			btn_irq_init_val <= btn_irq_init_val + 1;
			button_state_reg_cmp <= button_state_reg_init;
		end
	end 
	if (scan_clk_ctr == 5'b10001) begin
		scan_clk_ctr <= 5'b00000;
	end else begin
		scan_clk_ctr <= scan_clk_ctr + 1;
	end
		button_state_reg_init[scan_clk_ctr] <= mux_data_sel;
end

always_comb
begin
	mux_data_sel = ((~scan_clk_ctr[3] && MUX_DATA_IN_0_7) || (scan_clk_ctr[3] && MUX_DATA_IN_8_15));
	BTN_DATA_OUT = button_state_reg_cmp[data_out_ctr];
end

always_comb
begin
	if(scan_clk_ctr == 5'b01111) begin
		reset_out_ctr = 1'b1;
	end else begin
		reset_out_ctr = 1'b0;
	end
end

/*	
always@(button_state_reg_cmp) 
begin
	btn_irq_init_val <= btn_irq_init_val + 1;
end
*/

always@(posedge CLK_IN, posedge reset_out_ctr)
begin
	if(reset_out_ctr) begin
		data_out_ctr <= 4'b0000;
	end else begin
		data_out_ctr <= data_out_ctr + 1;
	end
end
	




endmodule