module testbench_simple




`timescale 10ns/1ns;

logic CLK_10MHZ;
logic SAMPLE_FREQ;
logic DIN;
logic CLK_IN;
logic CLK_IN_BU;
logic MUX_DATA_IN_0_7;
logic MUX_DATA_IN_8_15;
logic [2:0] MUX_LINE;
logic BTN_DATA_OUT;
logic BTN_IRQ;
logic N_CS;
logic SDO;
logic SCLK;
logic [9:0] LEDR = '0;

//internal signals

logic mux_data_sel;
logic scan_clk_ctr[3:0];
logic [15:0] shift_data_in_u16;
logic [3:0] bit_index_ctr;
logic [1:0] present_state;
logic [1:0] next_state;
logic [3:0] mux_4;

//data injection

logic [15:0] data = 16'b0110101010101011;

sequencer_dsp dut(.*);

initial
begin
	CLK_10MHZ = 1'b0;
	forever #50 CLK_10MHZ = ~CLK_10MHZ;
end

initial 
begin
	testbench_simple.dut.div_by_2e8 = 8'b0;
	testbench_simple.dut.comms_1.shift_data_in_u16 = 16'b0;
end


always@(posedge SAMPLE_FREQ) begin

	CLK_IN = 1'b0;
	DIN = 1'b0;
	#1000ns;
	for(int i = 0; i <16; i++) begin
	   CLK_IN = 1'b0;
		DIN = data[i];
		#100ns;
		CLK_IN = 1'b1;
		#100ns;
	end
	CLK_IN = 1'b0;
	DIN = 1'b0;

end

initial 
begin
   #1ms;
	$finish;
end

assign shift_data_in_u16 = testbench_simple.dut.comms_1.shift_data_in_u16;
assign bit_index_ctr = testbench_simple.dut.comms_1.bit_index_ctr;
assign present_state = testbench_simple.dut.dac_1.present_state;
assign next_state = testbench_simple.dut.dac_1.next_state;
assign mux_4 = testbench_simple.dut.dac_1.mux_4;

	


endmodule