#include "keyboard.h"
#include "hardware/gpio.h"
#include "stdio.h"
#include "defs.h"
#include "string"

keyboard::keyboard()
{
    gpio_init(MUXSEL_0);
    gpio_init(MUXSEL_1);
    gpio_init(MUXSEL_2);
    gpio_init(IN_0_7);
    gpio_init(IN_8_15);
    gpio_init(IN_16_23);
    gpio_set_dir(MUXSEL_0, true);
    gpio_set_dir(MUXSEL_1, true);
    gpio_set_dir(MUXSEL_2, true);
    gpio_set_dir(IN_0_7, false);
    gpio_set_dir(IN_8_15, false);
    gpio_set_dir(IN_16_23, false);

    
    
}


void keyboard::get_keys_state() //idea: modify function to pass in keyvalues for playback mode
{
    uint32_t keystate = 0;
    for(char index=0; index<8; index++)
    {
        gpio_put(MUXSEL_0, index & 0b00000001);
        gpio_put(MUXSEL_1, index & 0b00000010);
        gpio_put(MUXSEL_2, index & 0b00000100);
        timer_busy_wait_us(timer1_hw, sleep);
        keystate = keystate + (gpio_get(IN_0_7) << index) + (gpio_get(IN_8_15) << index+8) + (gpio_get(IN_16_23) << index+16);
        timer_busy_wait_us(timer1_hw, sleep);
    }
    uint32_t new_state = keystate ^ uint32_t(16768255); //default bitpattern = 16768255
    uint32_t compare = new_state^old_state;
    int key = 0;
    if(compare > 0){
        for(int shamt = 0; shamt < 32; shamt++){
            if(compare == 1){ //key event (press/unpress)
                int keypress_val = keymappings[shamt];
                if(0<=keypress_val && keypress_val<=18){
                    last_pressed = keypress_val + octave_shift;
                    atom_keyPress = new_state;
                    break;
                }
                else{
                    if(keypress_val == 19){ //dec. octave
                        octave_shift = octave_shift - 6;
                        if(octave_shift < 0){
                            octave_shift = 0;
                        }
                        else{
                        } 
                    }
                    else if(keypress_val == 20){ //inc. octave
                        octave_shift = octave_shift + 6;
                        if(octave_shift > 60){
                            octave_shift = 60;
                        }
                        else{
                        }
                    }
                    else{ //rotary button
                        toggle++;
                        if(toggle==1){
                            atom_rotPress.store(true);
                            toggle++;
                        }
                        else if(toggle==3){
                            toggle = 0;
                        }
                    }
                    last_pressed = last_pressed;
                }
            }
            else if(compare == 0){
                last_pressed = last_pressed;
            }
        compare = compare >> 1;
        }
    }
    
    old_state = new_state; 
    //printf("key: %d \r\n", last_pressed);
}
