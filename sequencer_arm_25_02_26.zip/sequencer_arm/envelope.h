#ifndef ENVELOPE_H
#define ENVELOPE_H
#include "pico/stdlib.h"

class envelope
{
    public:
        envelope();
        void update(bool keypress);
        void calc_env_coef();
        float getEnvCoef();
        int att_smp; float flt_att_incr;
        int dec_smp; float flt_dec_incr;
        float flt_sus_lvl;
        int rel_smp; float flt_rel_incr;
    private:
        uint64_t running_counter_att_to_sus = 0;
        uint64_t running_counter_rel = 0;
        float env_coef = 0;
        float capture_amplt;
        bool isReleased = false;
        float calc_rel();
        
        

};

#endif