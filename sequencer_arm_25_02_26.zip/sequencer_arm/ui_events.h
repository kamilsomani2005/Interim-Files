#ifndef UI_EVENTS
#define UI_EVENTS
#include "page_enums.h"
#include "page_mixer.h"

class ui_events 
{
    public:
        ui_events();
        void control_loop();
        int GLOBAL_ROT_LINK;
    private:
        page_mixer _page_mixer;
        pageNames pagenames;
};

#endif