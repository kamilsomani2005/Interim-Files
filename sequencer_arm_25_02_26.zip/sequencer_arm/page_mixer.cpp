#include "pico/stdlib.h"
#include "page_mixer.h"
#include "widgets.h"

#define BASE_POSX 4
#define BASE_POSY 4
#define TEXTBOX_WIDTH_Y 11
#define INSTR_SPACINGS 80

page_mixer::page_mixer()
{
    STATIC_synth1_text.text_create("lead", BASE_POSX, BASE_POSY, WHITE);
    oscs_button = new widgets(BASE_POSX, BASE_POSY+TEXTBOX_WIDTH_Y, "waveform", WHITE);
    envs_button = new widgets(BASE_POSX, BASE_POSY+TEXTBOX_WIDTH_Y*2, "envelope", WHITE);
    synth1_volume = new widgets(BASE_POSX+15, BASE_POSY+TEXTBOX_WIDTH_Y*6, "volume", WHITE, 0);
    //load in member highlight/n_highlight functions into a vector here for selector funct.in ui
}

void page_mixer::showAll()
{
    oscs_button->showDefault();
    envs_button->showDefault();
    synth1_volume->showDefault();

    STATIC_line1.vline(79, 0, 240);
    STATIC_line2.vline(159, 0, 240);
    STATIC_line3.vline(239, 0, 240);
    STATIC_synth1_text.text_show();
}

void page_mixer::hideAll()
{
    oscs_button->hide();
    envs_button->hide();
    synth1_volume->hide();
    STATIC_line1.erase_area(79, 0, 1, 240);
    STATIC_line2.erase_area(159, 0, 1, 240);
    STATIC_line1.erase_area(239, 0, 1, 240);
    STATIC_synth1_text.text_hide();
}

