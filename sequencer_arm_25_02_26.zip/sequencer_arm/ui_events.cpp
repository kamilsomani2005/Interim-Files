#include "pico/stdlib.h"
#include "ui_events.h"

ui_events::ui_events()
{
    pagenames = pageNames::MIXER;
}

void ui_events::control_loop()
{
    switch(pagenames)
    {
        case(pageNames::MIXER):
            _page_mixer.showAll();
            break;
    }
}