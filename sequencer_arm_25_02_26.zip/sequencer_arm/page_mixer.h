#ifndef PAGE_MIXER_H
#define PAGE_MIXER_H
#include "widgets.h"
#include "screen.h"
#include "page_enums.h"

class page_mixer
{
    public:
        page_mixer();
        void showAll();
        void hideAll();
    private:
        widgets* oscs_button;
        widgets* envs_button;
        widgets* synth1_volume;
        screen STATIC_line1;
        screen STATIC_line2;
        screen STATIC_line3;
        text STATIC_synth1_text;
        

};

#endif 