#include "envelope.h"
#include <stdio.h>
#include "pico/stdlib.h"
#include "defs.h"

#include "hardware/gpio.h" //dummy

envelope::envelope()
{
    gpio_init(25);
    gpio_set_dir(25, true);
    att_smp = 1;
    dec_smp = 1;
    flt_sus_lvl = 1.0f;
    rel_smp = 1;
    flt_att_incr = 1.0f/float(att_smp);
    flt_dec_incr = (1.0f-flt_sus_lvl)/float(dec_smp);
    flt_rel_incr = 1.0f/float(rel_smp);
}


void envelope::update(bool keypress)
{
    if(keypress){
        gpio_put(25, true);
        running_counter_att_to_sus ++;
        running_counter_rel = 0;
        isReleased = false;

    }
    else{
        gpio_put(25, false);
        running_counter_att_to_sus  = 0;
        running_counter_rel ++;
        isReleased = true;
    }
    
}

void envelope::calc_env_coef()
{
    
    if(running_counter_att_to_sus <= att_smp && !isReleased){
        env_coef = flt_att_incr*running_counter_att_to_sus;
    }
    else if(att_smp < running_counter_att_to_sus && running_counter_att_to_sus <= (att_smp+dec_smp) && !isReleased){ //att_smp+dec_smp to become precomputed
        uint derived_counter = running_counter_att_to_sus-(att_smp-1);
        env_coef = 1.0f - (flt_dec_incr*derived_counter);
    }
    else if((att_smp+dec_smp) < running_counter_att_to_sus && !isReleased){
        env_coef = flt_sus_lvl;
    }
    else if(isReleased && running_counter_rel == 1){
        capture_amplt = env_coef;
        env_coef = calc_rel();
    }
    else if(isReleased && running_counter_rel > 1){
        env_coef = calc_rel();
    }
    else{
        env_coef = 1.0f;
    }
}

float envelope::getEnvCoef()
{
    return env_coef;
}

float envelope::calc_rel()
{
    float val;
    if(env_coef <= 0.0f){   //may be problematic due to it going -ve
        val = 0.0f;
    } else {
        val = capture_amplt - (flt_rel_incr*running_counter_rel);
    }
    return val;
}

 





