#include "pico/stdlib.h"
#include "widgets.h"

widgets::widgets(int posx, int posy, std::string textstr, uint32_t colour)
{
    widgets::textsprite.text_create(textstr, posx, posy, colour);
    widgettype = button;
}

widgets::widgets(int posx, int posy, std::string textstr, uint32_t colour, int default_posn)
{
    widgets::textsprite.text_create(textstr, posx-10, posy+150, colour); //align these correctly
    widgets::fadersprite.fader_create(posx, posy, default_posn);
    fader_pos_link = &widgets::fadersprite.variable;
    widgettype = faderw;
}

void widgets::highlightText()
{
    textsprite.text_show_with_box_inv();
}

void widgets::n_highlightText()
{
    textsprite.text_show_with_box();
}

void widgets::showDefault()
{
    switch(widgettype)
    {
        case(button):
            textsprite.text_show_with_box();
            break;
        case(faderw):
            textsprite.text_show_with_box();
            fadersprite.fader_show();
            break;
    }
}

void widgets::hide()
{
    switch(widgettype)
    {
        case(button):
            textsprite.text_hide_with_box();
            break;
        case(faderw):
            textsprite.text_hide_with_box();
            fadersprite.fader_hide();
            break;
    }
}

pageNames widgets::scanForChanges()
{
    return pageNames::_NOCHANGE;
}

