#ifndef ROTARY_H
#define ROTARY_H


class rotary
{
    public:
        rotary();
        void pointToTunable(int *var_to_modify);
        void rotary_handler();
        int getCaseFromGPIO();
    private:
        int *var;
        bool ROT_A_state;
        bool ROT_B_state;
        int state;
};       

#endif 