#ifndef WIDGETS_H
#define WIDGETS_H
#include "text.h"
#include "fader.h"
#include "page_enums.h"
#include <string>

class widgets
{
    enum widgetType
    {
        button, faderw
    };
    public:
        widgets(int posx, int posy, std::string textstr, uint32_t colour); //button ctor
        widgets(int posx, int posy, std::string textstr, uint32_t colour, int default_posn); //fader ctor
        void highlightText();
        void n_highlightText();
        pageNames scanForChanges();
        void showDefault ();
        void hide();
    private:
        widgetType widgettype;
        text textsprite;
        fader fadersprite;
        int* fader_pos_link;

};

#endif