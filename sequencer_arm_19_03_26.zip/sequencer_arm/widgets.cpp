#include "pico/stdlib.h"
#include "widgets.h"

//############## BUTTON FOR NAVIGATING #################//
widgets::widgets(int posx, int posy, std::string textstr, uint32_t colour, pageNames next_page) 
{
    widgets::textsprite.text_create(textstr, posx, posy, colour);
    widgettype = button;
    nextPage = next_page;
}

//############# GENERIC FADER ######################//
widgets::widgets(int posx, int posy, std::string textstr, uint32_t colour, int default_posn, int* var)
{
    widgets::textsprite.text_create(textstr, posx-10, posy+150, colour); 
    widgets::fadersprite.fader_create(posx, posy, default_posn);
    variableptr = var;
    widgettype = faderw;
}


//############# GENERIC SCROLL BUTTON ######################//
widgets::widgets(int posx, int posy, std::string textstr, std::vector<std::string> strings, uint32_t colour, int* state)
{
    widgets::textsprite.text_create(textstr, posx, posy, colour);
    widgets::textsprite_2.text_create(strings, posx, posy-TEXTBOX_WIDTH_Y, colour);
    variableptr = state;
    widgettype = scrollbutton;
}
    

void widgets::highlightText()
{
    textsprite.text_show_with_box_inv();
}

void widgets::n_highlightText()
{
    textsprite.text_show_with_box();
}

void widgets::showDefault()
{
    switch(widgettype)
    {
        case(button):
            textsprite.text_show_with_box();
            break;
        case(faderw):
            textsprite.text_show_with_box();
            fadersprite.variable = *variableptr;
            fadersprite.fader_update();
            break;
        case(scrollbutton):
            textsprite.text_show_with_box();
            textsprite_2.text_show_with_box_inv();
            textsprite_2.text_update(*variableptr);
            break;
    }
}

void widgets::hide()
{
    switch(widgettype)
    {
        case(button):
            textsprite.text_hide_with_box();
            break;
        case(faderw):
            textsprite.text_hide_with_box();
            fadersprite.fader_hide();
            break;
        case(scrollbutton):
            textsprite.text_hide_with_box();
            textsprite_2.text_hide_with_box();
            break;
    }
}

//default update function here

widgets::widgetProperties widgets::scanForChanges(rotaryPushState pushEvent)
{
    widgets::widgetProperties _temp; 
    static bool pushstate = false;
    switch(widgettype)
    {
        case(button):

            switch(pushEvent)
            {
                case(rotaryPushState::NO_CHANGE):
                    _temp.pageDecision = pageNames::_NOCHANGE;
                    break;
                case(rotaryPushState::ACTIVATED):
                    _temp.pageDecision = nextPage;
                    break;
                default:
                    _temp.pageDecision = pageNames::_NOCHANGE;
                    break;

            }
            _temp.enabScrolling = true;
            _temp.varPointer = nullptr;
        
        break;
                    
        case(faderw):

            switch(pushEvent)
            {
                case(rotaryPushState::NO_CHANGE):
                    break;
                case(rotaryPushState::ACTIVATED):
                    pushstate = !pushstate;
                    break;
            }
            switch(pushstate)
            {
                case(true):
                    _temp.varPointer = variableptr;
                    _temp.enabScrolling = false;
                    fadersprite.variable = *variableptr;
                    fadersprite.fader_update();
                    break;
                case(false):
                    _temp.varPointer = nullptr;
                    _temp.enabScrolling = true;
            }
            _temp.pageDecision = pageNames::_NOCHANGE;
        
        break;

        case(scrollbutton):
            
            switch(pushEvent)
            {
                case(rotaryPushState::NO_CHANGE):
                    break;
                case(rotaryPushState::ACTIVATED):
                    pushstate = !pushstate;
                    break;
            }
            switch(pushstate)
            {
                case(true):
                    _temp.varPointer = variableptr;
                    _temp.enabScrolling = false;
                    textsprite_2.text_update(*variableptr);
                    break;
                case(false):
                    _temp.varPointer = nullptr;
                    _temp.enabScrolling = true;
            }
            _temp.pageDecision = pageNames::_NOCHANGE;
            
    }

    return _temp;
    
}

