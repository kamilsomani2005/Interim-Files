#include "pico/stdlib.h"
#include "ui_events.h"


ui_events::ui_events(int *synth1_master_vol, int *bass_master_vol, int *master_master_vol, int *kb_patch,
                     int *att1, int *dec1, int *sus1, int *rel1,
                     std::vector<std::string> strvec, int *osc1_wave,
                     int *cutoff, int *resonance, int *ft,
                     int *attbass, int *decbass, int *susbass, int *relbass,
                     int *oscbass_wave,
                     int *cutoffbass, int *resonancebass, int *ftbass,
                     int *attbassf, int *decbassf, int *susbassf, int *relbassf)
                    :_page_mixer(synth1_master_vol, bass_master_vol, master_master_vol, kb_patch),_page_env_synth1_v(att1, dec1, sus1, rel1)
                    ,_page_gen_synth1(strvec, osc1_wave),_page_filter_synth1(cutoff, resonance, ft),
                    _page_env_bass_v(attbass, decbass, susbass, relbass),_page_gen_bass(strvec, oscbass_wave),
                    _page_filter_bass(cutoffbass, resonancebass, ftbass),_page_env_bass_f(attbassf, decbassf, susbassf, relbassf)
{
    
    pagenames = pageNames::MIXER;
    GLOBAL_ROT_LINK = 0;
}

void ui_events::control_loop()
{
    
    switch(pagenames)
    {
        case(pageNames::_NOCHANGE):
            decision();
            if(pagenames != pageNames::_NOCHANGE){
                switch(pagenames_exit)
                {
                    case(pageNames::MIXER):
                        _page_mixer.hideAll();
                        break;
                    case(pageNames::SYNTH1_ENVELOPE):
                        _page_env_synth1_v.hideAll();
                        break;
                    case(pageNames::SYNTH1_GENERATOR):
                        _page_gen_synth1.hideAll();
                        break;
                    case(pageNames::SYNTH1_FILTER):
                        _page_filter_synth1.hideAll();
                        break;
                    case(pageNames::BASS_ENVELOPE):
                        _page_env_bass_v.hideAll();
                        break;
                    case(pageNames::BASS_GENERATOR):
                        _page_gen_bass.hideAll();
                        break;
                    case(pageNames::BASS_FILTER):
                        _page_filter_bass.hideAll();
                        break;
                    case(pageNames::BASS_FILTER_ENV):
                        _page_env_bass_f.hideAll();
                        break;
                    default:
                        break;
                }
            }
            break;
        case(pageNames::MIXER):
            objArray = _page_mixer.showAll();
            WidgetsOnPage = _page_mixer.returnNumWidgets();
            pagenames = pageNames::_NOCHANGE;
            pagenames_exit = pageNames::MIXER;
            break;
        case(pageNames::SYNTH1_ENVELOPE):
            objArray = _page_env_synth1_v.showAll();
            WidgetsOnPage = _page_env_synth1_v.returnNumWidgets();
            pagenames = pageNames::_NOCHANGE;
            pagenames_exit = pageNames::SYNTH1_ENVELOPE;
            break;
        case(pageNames::SYNTH1_GENERATOR):
            objArray = _page_gen_synth1.showAll();
            WidgetsOnPage = _page_gen_synth1.returnNumWidgets();
            pagenames = pageNames::_NOCHANGE;
            pagenames_exit = pageNames::SYNTH1_GENERATOR;
            break;
        case(pageNames::SYNTH1_FILTER):
            objArray = _page_filter_synth1.showAll();
            WidgetsOnPage = _page_filter_synth1.returnNumWidgets();
            pagenames = pageNames::_NOCHANGE;
            pagenames_exit = pageNames::SYNTH1_FILTER;
            break;
        case(pageNames::BASS_ENVELOPE):
            objArray = _page_env_bass_v.showAll();
            WidgetsOnPage = _page_env_bass_v.returnNumWidgets();
            pagenames = pageNames::_NOCHANGE;
            pagenames_exit = pageNames::BASS_ENVELOPE;
            break;
        case(pageNames::BASS_GENERATOR):
            objArray = _page_gen_bass.showAll();
            WidgetsOnPage = _page_gen_bass.returnNumWidgets();
            pagenames = pageNames::_NOCHANGE;
            pagenames_exit = pageNames::BASS_GENERATOR;
            break;
        case(pageNames::BASS_FILTER):
            objArray = _page_filter_bass.showAll();
            WidgetsOnPage = _page_filter_bass.returnNumWidgets();
            pagenames = pageNames::_NOCHANGE;
            pagenames_exit = pageNames::BASS_FILTER;
            break;
        case(pageNames::BASS_FILTER_ENV):
            objArray = _page_env_bass_f.showAll();
            WidgetsOnPage = _page_env_bass_f.returnNumWidgets();
            pagenames = pageNames::_NOCHANGE;
            pagenames_exit = pageNames::BASS_FILTER_ENV;
            break;
    }

}

void ui_events::decision() //return a page enum
{
    uint currCursor = getCursorIndex();
    objArray[currCursor]->highlightText();
    for(int scanThruIndex=0; scanThruIndex<WidgetsOnPage; scanThruIndex++){
        //perhaps include an update function here (coded in widgets) to update moving sprites such as volume meters, oscilloscope etc.
        if(scanThruIndex!=currCursor){
            objArray[scanThruIndex]->n_highlightText();
        }
    }
    widgets::widgetProperties _tmp = (objArray[currCursor]->scanForChanges(objForKeystates.get_rotary_button_state()));
    pagenames = _tmp.pageDecision;
    changeVar.pointToVariable(&GLOBAL_ROT_LINK, _tmp.varPointer, _tmp.enabScrolling);

}

uint ui_events::getCursorIndex()
{
    if(GLOBAL_ROT_LINK < 0){
        GLOBAL_ROT_LINK = 0;
    }
    else{
        GLOBAL_ROT_LINK = GLOBAL_ROT_LINK%WidgetsOnPage;
    }
    return GLOBAL_ROT_LINK;
}


