#ifndef TEXT_H
#define TEXT_H
#include "screen.h"
#include <vector>
#include <string>

class text : public screen 
{
    
    public:
        void text_create(std::string text, uint32_t posx, uint32_t posy, uint32_t colourmask);
        void text_create(std::vector<std::string> text, uint32_t posx, uint32_t posy, uint32_t colourmask);
        void text_show();
        void text_hide();
        void text_show_with_box();
        void text_hide_with_box();
        void text_show_with_box_inv();
        void text_update(int index);
        uint32_t this_posx;
        uint32_t this_posy;
    private:
        int len_txt;
        std::vector<uint32_t> buf;
        std::vector<std::string> strvec;
        int sizeof_buffer;
        unsigned char CM_H;
        unsigned char CM_L;
        uint32_t saved_colourmask;

        
        
};

#endif