#ifndef UI_EVENTS
#define UI_EVENTS
#include <vector>
#include <string>
#include "pico/multicore.h"

#include "page_enums.h"
#include "push_state_enums.h"
#include "defs.h"

#include "page_mixer.h"
#include "page_envelope.h"
#include "page_generator.h"
#include "page_filter.h"

#include "widgets.h"
#include "keyboard.h"
#include "rotary.h"

class ui_events 
{
    public:
        ui_events   (int *synth1_master_vol, int *bass_master_vol, int *master_master_vol, int *kb_patch,
                     int *att1, int *dec1, int *sus1, int *rel1,
                     std::vector<std::string> strvec, int *osc1_wave,
                     int *cutoff, int *resonance, int *ft,
                     int *attbass, int *decbass, int *susbass, int *relbass,
                     int *oscbass_wave,
                     int *cutoffbass, int *resonancebass, int *ftbass,
                     int *attbassf, int *decbassf, int *susbassf, int *relbassf);
        void control_loop();
        signed int GLOBAL_ROT_LINK;
        signed int VARIABLE;
    private:
        page_mixer _page_mixer;
        page_envelope _page_env_synth1_v, _page_env_bass_v, _page_env_bass_f;
        page_generator _page_gen_synth1, _page_gen_bass;
        page_filter _page_filter_synth1, _page_filter_bass;



        rotary changeVar;
        keyboard objForKeystates;
        pageNames pagenames, pagenames_exit;
        rotaryPushState pushState;
        void decision();
        std::vector<widgets*> objArray;
        uint getCursorIndex();
        int WidgetsOnPage;

};

#endif