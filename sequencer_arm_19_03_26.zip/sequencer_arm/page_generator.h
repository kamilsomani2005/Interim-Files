#ifndef PAGE_GENERATOR_H
#define PAGE_GENERATOR_H
#include "widgets.h"
#include "screen.h"
#include "page_enums.h"
#include "visual_defs.h"
#include <vector>
#include <string>

class page_generator
{
    public:
        page_generator(std::vector<std::string> strs, int* osc_type_1);
        std::vector<widgets*> showAll();
        void hideAll();
        int returnNumWidgets();
    private:
        widgets* osc1;
        widgets* osc2;
        text STATIC_generator;
        widgets* back_button;
        

};

#endif 