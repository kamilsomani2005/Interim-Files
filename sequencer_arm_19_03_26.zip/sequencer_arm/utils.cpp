#include "utils.h"
#include "pico/stdlib.h"

float logTable[128] = { //array made by gen. AI
    1.f, 1.f, 1.f, 1.f, 1.f, 2.f, 2.f, 2.f,
    2.f, 2.f, 2.f, 2.f, 3.f, 3.f, 3.f, 3.f,
    4.f, 4.f, 4.f, 5.f, 5.f, 6.f, 6.f, 7.f,
    7.f, 8.f, 9.f, 9.f, 10.f, 11.f, 12.f, 13.f,
    14.f, 16.f, 17.f, 18.f, 20.f, 22.f, 24.f, 26.f,
    28.f, 30.f, 33.f, 36.f, 39.f, 42.f, 46.f, 50.f,
    54.f, 59.f, 64.f, 70.f, 76.f, 82.f, 89.f, 97.f,
    105.f, 115.f, 124.f, 135.f, 147.f, 160.f, 174.f, 189.f,
    205.f, 223.f, 242.f, 263.f, 286.f, 311.f, 338.f, 367.f,
    399.f, 433.f, 471.f, 512.f, 556.f, 605.f, 657.f, 714.f,
    776.f, 843.f, 917.f, 996.f, 1082.f, 1176.f, 1278.f, 1389.f,
    1510.f, 1641.f, 1783.f, 1938.f, 2106.f, 2289.f, 2488.f, 2703.f,
    2938.f, 3193.f, 3470.f, 3771.f, 4098.f, 4454.f, 4840.f, 5260.f,
    5716.f, 6212.f, 6751.f, 7336.f, 7973.f, 8664.f, 9416.f, 10233.f,
    11121.f, 12087.f, 13136.f, 14275.f, 15514.f, 16860.f, 18323.f, 19914.f,
    21642.f, 23520.f, 25560.f, 27777.f, 30186.f, 32804.f, 35649.f, 38741.f
};

int logTableInt[128] = { //array made by gen. AI
    1, 1, 1, 1, 1, 2, 2, 2,
    2, 2, 2, 2, 3, 3, 3, 3,
    4, 4, 4, 5, 5, 6, 6, 7,
    7, 8, 9, 9, 10, 11, 12, 13,
    14, 16, 17, 18, 20, 22, 24, 26,
    28, 30, 33, 36, 39, 42, 46, 50,
    54, 59, 64, 70, 76, 82, 89, 97,
    105, 115, 124, 135, 147, 160, 174, 189,
    205, 223, 242, 263, 286, 311, 338, 367,
    399, 433, 471, 512, 556, 605, 657, 714,
    776, 843, 917, 996, 1082, 1176, 1278, 1389,
    1510, 1641, 1783, 1938, 2106, 2289, 2488, 2703,
    2938, 3193, 3470, 3771, 4098, 4454, 4840, 5260,
    5716, 6212, 6751, 7336, 7973, 8664, 9416, 10233,
    11121, 12087, 13136, 14275, 15514, 16860, 18323, 19914,
    21642, 23520, 25560, 27777, 30186, 32804, 35649, 38741
};

void boundVariableMinZero(int &param){
    if(param < 0){
        param = 0;
    }
    else if(param > 127){
        param = 127;
    }
}

void boundVariableMaxMin(int &param, int lower, int upper){
    if(param <= lower){
        param = lower;
    }
    else if(param >= upper){
        param = upper;
    }
    else{
        param=param;
    }
}

float returnLinearAuto(int &param){
    boundVariableMinZero(param);
    return float(param*0.007874f);
}

float returnEnvSampleLogAuto(int &param){
    boundVariableMinZero(param);
    return logTable[param];
}

int returnEnvSampleLog(int param){
    return logTableInt[param];
}

float returnSelectFromParams(int &param, int v_sel, int upper, bool n_disable){
    boundVariableMaxMin(param, 0, upper);
    if(n_disable){
        if(param == v_sel){
            return 1.0f;
        }
        else{
            return 0.0f;
        }
    }
    else{
        return 1.0f;
    }
}





