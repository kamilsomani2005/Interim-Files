#include "pico/stdlib.h"
#include "page_mixer.h"
#include "widgets.h"

#define WIDGETS_ON_PAGE 11

page_mixer::page_mixer(int *synth1_master_volume, int *bass_master_volume, int* master_master_volume, int* kb_patch)
{
    STATIC_synth1_text.text_create("lead", BASE_POSX, BASE_POSY, CYAN);
    oscs_button = new widgets(BASE_POSX, BASE_POSY+TEXTBOX_WIDTH_Y, "waveform", CYAN, pageNames::SYNTH1_GENERATOR);
    envs_button = new widgets(BASE_POSX, BASE_POSY+TEXTBOX_WIDTH_Y*2, "envelope", CYAN, pageNames::SYNTH1_ENVELOPE);
    flt_button = new widgets(BASE_POSX, BASE_POSY+TEXTBOX_WIDTH_Y*3, "filter", CYAN, pageNames::SYNTH1_FILTER);
    synth1_volume = new widgets(BASE_POSX+15, BASE_POSY+TEXTBOX_WIDTH_Y*6, "volume", CYAN, 0, synth1_master_volume);

    STATIC_bass_text.text_create("bass", BASE_POSX+79, BASE_POSY, GREEN);
    oscs_bass_button = new widgets(BASE_POSX+79, BASE_POSY+TEXTBOX_WIDTH_Y, "waveform", GREEN, pageNames::BASS_GENERATOR);
    envs_bass_button = new widgets(BASE_POSX+79, BASE_POSY+TEXTBOX_WIDTH_Y*2, "envelope", GREEN, pageNames::BASS_ENVELOPE);
    flt_bass_button = new widgets(BASE_POSX+79, BASE_POSY+TEXTBOX_WIDTH_Y*3, "filter", GREEN, pageNames::BASS_FILTER);
    flt_env_bass_button = new widgets(BASE_POSX+79, BASE_POSY+TEXTBOX_WIDTH_Y*4, "filterenv", GREEN, pageNames::BASS_FILTER_ENV);
    bass_volume = new widgets(BASE_POSX+15+79, BASE_POSY+TEXTBOX_WIDTH_Y*6, "volume", GREEN, 0, bass_master_volume);

    STATIC_master_text.text_create("master", BASE_POSX+239+10, BASE_POSY, WHITE);
    master_volume = new widgets(BASE_POSX+15+239, BASE_POSY+TEXTBOX_WIDTH_Y*6, "volume", WHITE, 0, master_master_volume);
    patch_sel = new widgets(BASE_POSX+239+10, BASE_POSY+TEXTBOX_WIDTH_Y*2, "patch", patch_strs, WHITE, kb_patch);
    //load in member highlight/n_highlight functions into a vector here for selector funct.in ui
}

std::vector<widgets*> page_mixer::showAll()
{
    std::vector<widgets*> objArray;

    oscs_button->showDefault();
    envs_button->showDefault();
    flt_button->showDefault();
    synth1_volume->showDefault();

    oscs_bass_button->showDefault();
    envs_bass_button->showDefault();
    flt_bass_button->showDefault();
    flt_env_bass_button->showDefault();
    bass_volume->showDefault();


    master_volume->showDefault();
    patch_sel->showDefault();

    STATIC_line1.vline(79, 0, 240);
    STATIC_line2.vline(159, 0, 240);
    STATIC_line3.vline(239, 0, 240);
    STATIC_synth1_text.text_show();
    STATIC_master_text.text_show();
    STATIC_bass_text.text_show();

    objArray.push_back(oscs_button);
    objArray.push_back(envs_button);
    objArray.push_back(flt_button);
    objArray.push_back(synth1_volume);
    objArray.push_back(oscs_bass_button);
    objArray.push_back(envs_bass_button);
    objArray.push_back(flt_bass_button);
    objArray.push_back(flt_env_bass_button);
    objArray.push_back(bass_volume);
    objArray.push_back(patch_sel);
    objArray.push_back(master_volume);

    return objArray;

}

void page_mixer::hideAll()
{
    oscs_button->hide();
    envs_button->hide();
    flt_button->hide();
    synth1_volume->hide();
    master_volume->hide();

    oscs_bass_button->hide();
    envs_bass_button->hide();
    flt_bass_button->hide();
    flt_env_bass_button->hide();
    bass_volume->hide();

    patch_sel->hide();
    STATIC_line1.erase_area(79, 0, 1, 240);
    STATIC_line2.erase_area(159, 0, 1, 240);
    STATIC_line1.erase_area(239, 0, 1, 240);
    STATIC_synth1_text.text_hide();
    STATIC_master_text.text_hide();
    STATIC_bass_text.text_hide();
}

int page_mixer::returnNumWidgets()
{
    return WIDGETS_ON_PAGE;
}

