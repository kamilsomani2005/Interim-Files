#ifndef FILTERTYPE_ENUMS_H
#define FILTERTYPE_ENUMS_H

enum class filterType
{
    NONE,
    LOWPASS
};

#endif 