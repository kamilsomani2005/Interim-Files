#ifndef PAGE_MIXER_H
#define PAGE_MIXER_H
#include "widgets.h"
#include "screen.h"
#include "page_enums.h"
#include "visual_defs.h"
#include <string>
#include <vector>

class page_mixer
{
    public:
        page_mixer(int *synth1_master_volume, int *bass_master_volume, int *master_master_volume, int *kb_patch);
        std::vector<widgets*> showAll();
        void hideAll();
        int returnNumWidgets();
    private:
        std::vector<std::string> patch_strs = {"lead", "bass"};

        widgets* oscs_button;
        widgets* envs_button;
        widgets* flt_button;
        widgets* synth1_volume;
        text STATIC_synth1_text;

        widgets* oscs_bass_button;
        widgets* envs_bass_button;
        widgets* flt_bass_button;
        widgets* flt_env_bass_button;
        widgets* bass_volume;
        text STATIC_bass_text;

        screen STATIC_line1;
        screen STATIC_line2;
        screen STATIC_line3;
        


        text STATIC_master_text;
        widgets* master_volume;
        widgets* patch_sel;

        int DUMMY_VAR = 50;
        

};

#endif 