#include "pico/stdlib.h"
#include "page_generator.h"
#include "widgets.h"

#define WIDGETS_ON_PAGE 2

page_generator::page_generator(std::vector<std::string> strs, int* osc_type_1)
{
    STATIC_generator.text_create("waveform", BASE_POSX, BASE_POSY, WHITE);
    back_button = new widgets(319-34, BASE_POSY, "back", RED, pageNames::MIXER);
    osc1 = new widgets(BASE_POSX+15, BASE_POSY+40, "oscillator", strs, WHITE, osc_type_1);
    //load in member highlight/n_highlight functions into a vector here for selector funct.in ui
}

std::vector<widgets*> page_generator::showAll()
{
    std::vector<widgets*> objArray;

    osc1->showDefault();
    back_button->showDefault();

    STATIC_generator.text_show();

    objArray.push_back(osc1);
    objArray.push_back(back_button);

    return objArray;

}

void page_generator::hideAll()
{
    osc1->hide();
    back_button->hide();
    STATIC_generator.text_hide();
}

int page_generator::returnNumWidgets()
{
    return WIDGETS_ON_PAGE;
}