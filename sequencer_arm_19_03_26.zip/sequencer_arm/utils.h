#ifndef UTILS_H
#define UTILS_H

extern float logTable[128];

extern int logTableInt[128];

void boundVariableMinZero(int &param);

float returnLinearAuto(int &param);

float returnEnvSampleLogAuto(int &param);

int returnEnvSampleLog(int param);

void boundVariableMaxMin(int &param, int lower, int upper); //define this in .cpp

float returnSelectFromParams(int &param, int v_sel, int upper, bool n_disable);

#endif