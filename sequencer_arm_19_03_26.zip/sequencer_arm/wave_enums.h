#ifndef WAVE_ENUMS_H
#define WAVE_ENUMS_H

enum class WaveEnums
{
    SINE,
    SAW,
    SQUARE,
    TRIANGLE,
    _COUNT
};

#endif