#include "pico/stdlib.h"
#include "page_filter.h"
#include "widgets.h"

#define WIDGETS_ON_PAGE 4

page_filter::page_filter(int* cutoff, int* resonance, int* ft)
{
    STATIC_filter.text_create("filter", BASE_POSX, BASE_POSY, WHITE);
    back_button = new widgets(319-34, BASE_POSY, "back", RED, pageNames::MIXER);
    filtertype = new widgets(BASE_POSX+15, BASE_POSY+40, "filter", filtertypes, WHITE, ft);
    cutoffw = new widgets(BASE_POSX+15+INSTR_SPACINGS, BASE_POSY+TEXTBOX_WIDTH_Y*6, "cutoff", WHITE, 0, cutoff);
    resonancew = new widgets(BASE_POSX+15+INSTR_SPACINGS*2, BASE_POSY+TEXTBOX_WIDTH_Y*6, "resonance", WHITE, 0, resonance); 
    //load in member highlight/n_highlight functions into a vector here for selector funct.in ui
}

std::vector<widgets*> page_filter::showAll()
{
    std::vector<widgets*> objArray;

    filtertype->showDefault();
    cutoffw->showDefault();
    resonancew->showDefault();
    back_button->showDefault();

    STATIC_filter.text_show();

    objArray.push_back(filtertype);
    objArray.push_back(cutoffw);
    objArray.push_back(resonancew);
    objArray.push_back(back_button);

    return objArray;

}

void page_filter::hideAll()
{
    filtertype->hide();
    cutoffw->hide();
    resonancew->hide();
    back_button->hide();
    STATIC_filter.text_hide();
}

int page_filter::returnNumWidgets()
{
    return WIDGETS_ON_PAGE;
}