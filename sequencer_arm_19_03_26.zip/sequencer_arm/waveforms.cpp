#include "pico/stdlib.h"
#include "waveforms.h"

waveforms::waveforms()
{
    /*
    static bool hasRun = false;
    if (hasRun) return;
    hasRun = true;
    */
    for(int i=1; i<=MAX_ADDITIVE_OSC_NO; i++)
    {
        saw_table.push_back(float(1.0/i));
        square_table_phases.push_back(0); 
        saw_table_phases.push_back(0);
        if(i%2 == 0)
        {
        square_table.push_back(0);
        tri_table.push_back(0);
        }
        else
        {
        square_table.push_back(float(1.0/i));
        tri_table.push_back(float(1.0/(i*i)));
        } 
    }
    //triangle wave default gen
    for(int i=1; i<=MAX_ADDITIVE_OSC_NO; i++)
    {
        if((i+1)%4 == 0)
        {
        tri_table_phases.push_back(88); 
        }
        else
        {
        tri_table_phases.push_back(0);
        }
    }

    sin_table.push_back(1.0f);
    sin_table_phases.push_back(0);

    for(int i=2; i<=MAX_ADDITIVE_OSC_NO; i++){
        sin_table.push_back(0.0f);
        sin_table_phases.push_back(0);
    }

    warr.push_back(&sin_table);
    warr.push_back(&saw_table);
    warr.push_back(&square_table);
    warr.push_back(&tri_table);
    parr.push_back(&sin_table_phases);
    parr.push_back(&saw_table_phases);
    parr.push_back(&square_table_phases);
    parr.push_back(&tri_table_phases);

    str_osc_types.push_back("sine");
    str_osc_types.push_back("saw");
    str_osc_types.push_back("square");
    str_osc_types.push_back("triangle");

}

vector<float>& waveforms::returnPtrWave()
{
    boundVariableMaxMin(wavetype, 0, int(WaveEnums::_COUNT)-1);
    return (*warr[wavetype]);
}

vector<int>& waveforms::returnPtrWavePhi()
{
    boundVariableMaxMin(wavetype, 0, int(WaveEnums::_COUNT)-1);
    return (*parr[wavetype]);
}
