#include <stdio.h>
#include <string>
#include <vector>
#include "pico/stdlib.h"
#include "generator.h"
#include "hardware/gpio.h"
#include "math.h"
#include "hardware/pio.h"
#include "pi_tx.pio.h"
#include "pico/multicore.h"
#include "screen.h"
#include "defs.h"
#include "rotary.h"
#include "keyboard.h"
#include "envelope.h"
#include "ui_events.h"
#include "utils.h"
#include "waveforms.h"
#include "pico/float.h"

//timer_start = timer_time_us_64(timer0_hw);
//sound generation
generator synth1, bass;
envelope adsr_synth1_v, adsr_bass_v, adsr_bass_f;
waveforms w_synth1, w_bass;

//IO instantiations
rotary ROTARY;
repeating_timer_t timer1;
keyboard keys;

//int buf_size;

PIO pio;
uint sm_tx;
uint offset_tx;

int master_vol = 50;
int channel_select = 0;


//need to figure out a better way to pass this into master_chn()

uint32_t master_chn(){
    float chn_1_out = adsr_synth1_v.getEnvCoef() * synth1.read_buffer() * returnLinearAuto(synth1.synth_master_volume) * returnSelectFromParams(channel_select, 0, 1, true);
    float chn_2_out = adsr_bass_v.getEnvCoef() * bass.read_buffer() * returnLinearAuto(bass.synth_master_volume) * returnSelectFromParams(channel_select, 1, 1, true);
    uint32_t digital_out = 32768*((chn_1_out+chn_2_out+1.0f)*returnLinearAuto(master_vol)); //modify this to bound by -32768, 32767 and make var int32_t (maybe temporarily?) remove +1.0f.
    if(digital_out > 65535) {digital_out = 65535;}
    return digital_out;
}



void sample_handler(uint gpio, uint32_t events) {
    pio_sm_clear_fifos(pio, sm_tx);
    bool keyPressed = keys.atom_keyPress.load();
    adsr_synth1_v.update(keyPressed);
    adsr_synth1_v.calc_env_coef();
    adsr_bass_v.update(keyPressed);
    adsr_bass_v.calc_env_coef();
    adsr_bass_f.update(keyPressed);
    pio_sm_put(pio, sm_tx, master_chn());
    ROTARY.rotary_handler();

}


void DEBUG_frequency_sweep_test()
{
    for(float i = 1.301; i < 4.301; i=i+0.035)
    {
        float logfreq = pow(10.0, i);
        int exp_sample_width = (int)round(float(SAMPLE_RATE-1)/logfreq);
        //synth1.waveform(logfreq, saw_table, saw_table_phases);
        printf("freq: %f, expected sample width: %d \r\n", logfreq, exp_sample_width);
        sleep_ms(2000);
    }
}

bool io_handler(repeating_timer_t *rt)
{
    keys.get_keys_state();
    return true;
}

void side()
{

add_repeating_timer_ms(IO_READ_RATE, io_handler, NULL, &timer1);
irq_set_priority(TIMER0_IRQ_1, 1);
keys.init_gpio();
float notefreq;
int bass_final_cutoff;

    while (true){
        adsr_bass_f.calc_env_coef();
        bass_final_cutoff = bass.cutoff-adsr_bass_f.getEnvCoefInt();
        notefreq = synth1.get_fundamental_freq(keys.last_pressed);
        synth1.filter(notefreq, int(returnEnvSampleLogAuto(synth1.cutoff)), (returnLinearAuto(synth1.resonance)*2)+0.707f);
        synth1.waveform(notefreq, w_synth1.returnPtrWave(), w_synth1.returnPtrWavePhi());
        bass.filter(notefreq, int(returnEnvSampleLogAuto(bass_final_cutoff)), (returnLinearAuto(bass.resonance)*2)+0.707f);
        bass.waveform(notefreq, w_bass.returnPtrWave(), w_bass.returnPtrWavePhi());
    }
}

void TEST_f2fp(float input){
    int32_t sfixed = (int32_t)(input * (float)(1 << (15)));
    printf("value: %d \r\n", sfixed);
}


int main()
{

stdio_init_all();

screen tft;
ROTARY.setupGPIO();
tft.init();

gpio_init(SAMPLE_CLK_FPGA);
gpio_set_dir(SAMPLE_CLK_FPGA, false);

bool success_tx_pio = pio_claim_free_sm_and_add_program_for_gpio_range(&pi_tx_program, &pio, &sm_tx, &offset_tx, CLK_OUT, 2, true);
pi_tx_program_init(pio, sm_tx, offset_tx, CLK_OUT, DATA_OUT);
gpio_set_irq_enabled_with_callback(SAMPLE_CLK_FPGA, GPIO_IRQ_EDGE_RISE, true, &sample_handler);
irq_set_priority(IO_IRQ_BANK0, 0);

multicore_launch_core1(side); //move this down perhaps?

ui_events UI(&synth1.synth_master_volume, &bass.synth_master_volume, &master_vol, &channel_select,    //MIXER
             &adsr_synth1_v.att_link, &adsr_synth1_v.dec_link, &adsr_synth1_v.flt_int, &adsr_synth1_v.rel_link, //AMP ADSR SYNTH 1 
             w_synth1.str_osc_types, &w_synth1.wavetype, //WAVEFORM SYNTH 1
             &synth1.cutoff, &synth1.resonance, &synth1.filtertype, //FILTER SYNTH1
             &adsr_bass_v.att_link, &adsr_bass_v.dec_link, &adsr_bass_v.flt_int, &adsr_bass_v.rel_link, //AMP ADSR BASS
             &w_bass.wavetype, //WAVEFORM BASS
             &bass.cutoff, &bass.resonance, &bass.filtertype, //FILTER BASS
             &adsr_bass_f.att_link, &adsr_bass_f.dec_link, &adsr_bass_f.flt_int, &adsr_bass_f.rel_link); //FLT ADSR BASS
             

ROTARY.pointToSelector(&UI.GLOBAL_ROT_LINK);


    while (true){
        //adsr calc here
        UI.control_loop();
        sleep_ms(100);
        adsr_synth1_v.calcNewParams();
        adsr_bass_v.calcNewParams();
        adsr_bass_f.calcNewParams();
        TEST_f2fp(0.0002674f);
        //printf("val: \r\n");
    }
}






