#ifndef WIDGETS_H
#define WIDGETS_H
#include "text.h"
#include "fader.h"
#include "page_enums.h"
#include "push_state_enums.h"
#include "visual_defs.h"
#include <string>
#include <vector>

class widgets
{
    enum widgetType
    {
        button, faderw, scrollbutton
    };
    public:
        struct widgetProperties{ 
            pageNames pageDecision;
            int *varPointer;
            bool enabScrolling;
        };
        widgets(int posx, int posy, std::string textstr, uint32_t colour, pageNames next_page); //button ctor
        widgets(int posx, int posy, std::string textstr, uint32_t colour, int default_posn, int* var); //fader ctor
        widgets(int posx, int posy, std::string textstr, std::vector<std::string> strings, uint32_t colour, int* state); //scrollbutton ctor
        void highlightText();
        void n_highlightText();
        widgetProperties scanForChanges(rotaryPushState pushState);
        void showDefault ();
        void hide();
    private:
        pageNames nextPage;
        widgetType widgettype;
        text textsprite; 
        text textsprite_2;   //inneficient, each object constructed even for widgets that dont need some types of objs.
                                        //find a better way to implement?
        fader fadersprite;
        int* variableptr;

};

#endif