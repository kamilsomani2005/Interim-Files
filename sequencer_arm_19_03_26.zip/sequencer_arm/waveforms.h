#ifndef WAVEFORMS_H
#define WAVEFORMS_H
#include <vector>
#include <string>
#include "defs.h"
#include "utils.h"
#include "wave_enums.h"

using std::vector;
using std::string;

class waveforms
{
    public:
        waveforms();
        vector<vector<float>*> warr;
        vector<vector<int>*> parr;
        int wavetype = 0;
        vector<float>& returnPtrWave();
        vector<int>& returnPtrWavePhi();
        vector<string> str_osc_types;

    private:
        vector<float> sin_table;
        vector<int> sin_table_phases;
        vector<float> saw_table;
        vector<int> saw_table_phases;
        vector<float> square_table;
        vector<int> square_table_phases;
        vector<float> tri_table;
        vector<int> tri_table_phases; 

};


#endif