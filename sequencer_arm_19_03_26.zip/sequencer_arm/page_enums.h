#ifndef PAGE_ENUMS_H
#define PAGE_ENUMS_H

enum class pageNames
{
    _NOCHANGE,
    MIXER,
    SYNTH1_GENERATOR,
    SYNTH1_ENVELOPE,
    SYNTH1_FILTER,
    BASS_GENERATOR,
    BASS_ENVELOPE,
    BASS_FILTER,
    BASS_FILTER_ENV

};

#endif