#ifndef ENVELOPE_H
#define ENVELOPE_H
#include "pico/stdlib.h"
#include "utils.h"

class envelope
{
    public:
        envelope();
        void update(bool keypress);
        void calc_env_coef();
        float getEnvCoef();
        int getEnvCoefInt();
        int att_smp; float flt_att_incr; int att_link;
        int dec_smp; float flt_dec_incr; int dec_link;
        int flt_int; float flt_sus_lvl; int flt_link;
        int rel_smp; float flt_rel_incr; int rel_link;
        void calcNewParams();
    private:
        uint64_t running_counter_att_to_sus = 0;
        uint64_t running_counter_rel = 0;
        float env_coef = 0;
        float capture_amplt;
        bool isReleased = false;
        float calc_rel();
        
        

};

#endif