#ifndef PAGE_FILTER_H
#define PAGE_FILTER_H
#include "widgets.h"
#include "screen.h"
#include "page_enums.h"
#include "visual_defs.h"
#include <vector>
#include <string>

class page_filter
{
    public:
        page_filter(int* cutoff, int* resonance, int* ft);
        std::vector<widgets*> showAll();
        void hideAll();
        int returnNumWidgets();
    private:
        std::vector<std::string> filtertypes = {"none", "lowpass"};
        widgets* cutoffw;
        widgets* resonancew;
        widgets* filtertype;
        text STATIC_filter;
        widgets* back_button;
        

};

#endif 