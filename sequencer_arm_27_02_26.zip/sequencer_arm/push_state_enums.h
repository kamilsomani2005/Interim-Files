#ifndef PUSH_STATE_ENUMS_H
#define PUSH_STATE_ENUMS_H

enum class rotaryPushState
{
    NO_CHANGE,
    ACTIVATED,
    DEACTIVATED
};

#endif