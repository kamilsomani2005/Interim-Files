#ifndef KEYBOARD_H
#define KEYBOARD_H
#include "pico/stdlib.h"
#include <atomic>
#include "pico/multicore.h"
#include "push_state_enums.h"

using std::atomic;

class keyboard
{
    public:
        void init_gpio();
        void get_keys_state();
        int last_pressed;
        static rotaryPushState state;
        atomic<bool> atom_keyPress = false;
        inline static atomic<bool> atom_rotarySelect;
        inline static atomic<bool> atom_rotaryDeselect;
        rotaryPushState get_rotary_button_state();

    private:
        rotaryPushState pushState;
        uint32_t mask;
        uint64_t sleep = 3;
        uint32_t old_state = 0;
        int toggle = 0;
        int keytoggle = 0;
        signed int octave_shift = 36;
        int keymappings[24] = {6, 7, 9, 11, 13, 16, 14, 12, 0, 0, 18, 19, 20, 21, 17, 15, 8, 5, 3, 1, 10, 0, 2, 4};
        
        
    

};


#endif