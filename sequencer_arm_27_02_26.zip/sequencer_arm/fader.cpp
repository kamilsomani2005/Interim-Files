#include "fader.h"
#include "pico/stdlib.h"
#include "shapedata.h"

void fader:: fader_create(uint32_t posx, uint32_t posy, int def_pos)
{
    scaled_fader_position_y = def_pos;
    this_posx = posx;
    this_posy = posy;
}

void fader::fader_show()
{
    vline(this_posx, this_posy, 128);
    vline(this_posx+1, this_posy, 128);
    vline(this_posx+2, this_posy, 128);
    vline(this_posx+3, this_posy, 128);
    def_wr_area(this_posx-10, this_posy+112-scaled_fader_position_y, 24, 32);
    wr_seq_from_arr32_orig_colors(&fader_sprite, 768);
}

void fader::fader_hide()
{
    erase_area(this_posx-10, this_posy-16, 24, 128+32);
}

void fader::fader_update()
{
    erase_area(this_posx-10, this_posy+112-scaled_fader_position_y, 24, 32);
    vline(this_posx, this_posy, 128);
    vline(this_posx+1, this_posy, 128);
    vline(this_posx+2, this_posy, 128);
    vline(this_posx+3, this_posy, 128);
    scaled_fader_position_y = var_to_fad_pos();
    def_wr_area(this_posx-10, this_posy+112-scaled_fader_position_y, 24, 32);
    wr_seq_from_arr32_orig_colors(&fader_sprite, 768);
    //write_cmd(0x00); ??
    //write_cmd(0x00);
    
}

int fader::var_to_fad_pos()
{
    if(variable > 128)
    {
        variable = 128;
    }
    else if(variable < 0)
    {
        variable = 0;
    }
    else
    {
        variable = variable;
    }
    return variable;
}

int* fader::get_var_ptr()
{
    return &variable;
}