#ifndef PAGE_MIXER_H
#define PAGE_MIXER_H
#include "widgets.h"
#include "screen.h"
#include "page_enums.h"
#include "visual_defs.h"
#include <vector>

class page_mixer
{
    public:
        page_mixer(int *synth1_master_volume);
        std::vector<widgets*> showAll();
        void hideAll();
        int returnNumWidgets();
    private:
        widgets* oscs_button;
        widgets* envs_button;
        widgets* synth1_volume;
        screen STATIC_line1;
        screen STATIC_line2;
        screen STATIC_line3;
        text STATIC_synth1_text;
        int DUMMY_VAR = 50;
        

};

#endif 