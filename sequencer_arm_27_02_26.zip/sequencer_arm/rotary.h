#ifndef ROTARY_H
#define ROTARY_H


class rotary
{
    public:
        void setupGPIO();
        void pointToSelector(int *var_to_modify);
        void pointToVariable(int *scrollpos_to_modify, int *var_to_modify, bool enabScrolling);
        void rotary_handler();
        int getCaseFromGPIO();
    private:
        inline static int *faderval_y;
        inline static int *var;
        bool ROT_A_state;
        bool ROT_B_state;
        int state;
};       

#endif 