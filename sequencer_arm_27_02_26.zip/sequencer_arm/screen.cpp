#include "hardware/gpio.h"
#include <stdio.h>
#include <string>
#include "pico/stdlib.h"
#include "screen.h"
#include "shapedata.h"
#include "defs.h"
#include <vector>

#define SC_GPIO_ST_PIN 10

//controller ILI9340
//TFT STD022ATFT
//######   MAPPINGS ########


#define H_MASK 0x0000ff00
#define L_MASK 0x000000ff


void screen::init()
{
    for(int i=0; i <8; i++)
    {
        gpio_init(SC_GPIO_ST_PIN+i);
        gpio_set_dir(SC_GPIO_ST_PIN+i, true);
    }

    gpio_init(RESET);
    gpio_set_dir(RESET, true);

    gpio_init(DCX);
    gpio_set_dir(DCX, true);

    gpio_init(WRX);
    gpio_set_dir(WRX, true);

    gpio_put(WRX, 1);
    gpio_put(DCX, 1);
    gpio_put(RESET, 0);
    sleep_ms(50);
    gpio_put(RESET, 1);
    sleep_ms(150);
    gpio_put(WRX, 0);
    
    write_cmd(0x01);
    sleep_ms(5);
    write_cmd(0x11);
    sleep_ms(150);
    write_cmd(0x3a); //pixel format set pg.134
    write_data(0x55); //default 0x55 
    write_cmd(0x36); //mem access ctrl (MADCTL) pg.127
    write_data(0b00101000); //default 0x48 
    write_cmd(0x29);
    //write_cmd(0x39); //idle mode on (reduced colour)

    //black screen (default)
    write_cmd(0x2a);
    write_data(0x00);
    write_data(0x00);
    write_data(0x01);
    write_data(0x3f);
    write_cmd(0x2b);
    write_data(0x00);
    write_data(0x00);
    write_data(0x00);
    write_data(0xef);  //ef
    write_cmd(0x2c);
    for(int pixel_h = 0; pixel_h < 240; pixel_h ++)
    {
        for(int pixel_v = 0; pixel_v < 320; pixel_v ++)
        {
            write_data(0x00);
            write_data(0x00);
        }
      
    }

}


void screen::write_cmd(uint32_t cmd)
{
    gpio_put(DCX, 0);
    gpio_set_mask(cmd << SC_GPIO_ST_PIN);
    gpio_put(WRX, 1);
    gpio_put(WRX, 0);
    gpio_clr_mask(cmd << SC_GPIO_ST_PIN);
}

void screen::write_data(uint32_t data)
{
    gpio_put(DCX, 1);
    gpio_set_mask(data << SC_GPIO_ST_PIN);
    gpio_put(WRX, 1);
    gpio_put(WRX, 0);
    gpio_clr_mask(data << SC_GPIO_ST_PIN);
}

void screen::def_wr_area(uint32_t posx, uint32_t posy, uint32_t sizx, uint32_t sizy)
{
    write_cmd(0x2a);
    write_data((H_MASK & posx) >> 8);
    write_data(L_MASK & posx);
    write_data((H_MASK & (posx+sizx-1)) >> 8);
    write_data(L_MASK & (posx+sizx-1));
    write_cmd(0x2b);
    write_data((H_MASK & posy) >> 8);
    write_data(L_MASK & posy);
    write_data((H_MASK & (posy+sizy-1)) >> 8);
    write_data(L_MASK & (posy+sizy-1));
    write_cmd(0x2c);
}

void screen::wr_seq_from_arr32(std::vector<uint32_t>* input_buffer, int sizeof_buf, unsigned char CM_H, unsigned char CM_L)
{
    for(int index =0; index<sizeof_buf; index++)
    {
        write_data((CM_H & ((*input_buffer)[index]) >> 8));
        write_data((CM_L & (*input_buffer)[index]));
    }
}

void screen::erase_area(uint32_t posx, uint32_t posy, uint32_t lenx, uint32_t leny)
{
    def_wr_area(posx, posy, lenx, leny);
    for(int buf_index =0; buf_index<(lenx*leny); buf_index++)
    {
        write_data(0x00);
        write_data(0x00);
    }
}

void screen::wr_seq_from_arr32_orig_colors(std::vector<uint32_t>* input_buffer, int sizeof_buf)
{
    for(int index =0; index<sizeof_buf; index++)
    {
        write_data((H_MASK & ((*input_buffer)[index])) >> 8);
        write_data(L_MASK & ((*input_buffer)[index]));
    }
}

void screen::wr_seq_from_arr32_inv(std::vector<uint32_t>* input_buffer, int sizeof_buf, unsigned char CM_H, unsigned char CM_L)
{
    for(int index =0; index<sizeof_buf; index++)
    {
        write_data((CM_H & (~(*input_buffer)[index]) >> 8));
        write_data((CM_L & ~(*input_buffer)[index]));
    }
}

void screen::hline(uint32_t posx, uint32_t posy, int length)
{
    def_wr_area(posx, posy, length, 1);
    for(int px=0; px<length; px++)
    {
        write_data(0xff);
        write_data(0xff);
    }
}

void screen::vline(uint32_t posx, uint32_t posy, int length)
{
    def_wr_area(posx, posy, 1, length);
    for(int px=0; px<length; px++)
    {
        write_data(0xff);
        write_data(0xff);
    }
}


void screen::DEBUG_make_boxes()
{
    write_cmd(0x2a);
    write_data(0x00);
    write_data(0x05);
    write_data(0x00);
    write_data(0x09);
    write_cmd(0x2b);
    write_data(0x00);
    write_data(0x05);
    write_data(0x00);
    write_data(0x09);
    write_cmd(0x2c);
    for(int pixel = 0; pixel < 25; pixel ++)
    {
        write_data(0b00000000);
        write_data(0b00011111);
    }
    write_cmd(0x00);

    write_cmd(0x2a);
    write_data(0x00);
    write_data(0x25);
    write_data(0x00);
    write_data(0x29);
    write_cmd(0x2b);
    write_data(0x00);
    write_data(0x25);
    write_data(0x00);
    write_data(0x29);
    write_cmd(0x2c);
    for(int pixel = 0; pixel < 25; pixel ++)
    {
        write_data(0b11111000);
        write_data(0b00000000);
    }
    write_cmd(0x00);
}
