#ifndef DEFS_H
#define DEFS_H

#define SAMPLE_RATE 39062
#define SAMPLE_PERIOD_US 25
#define BIT_DEPTH 16.0
#define PI 3.14159265
#define MAX_ADDITIVE_OSC_NO 1

// ###### PIN  MAPPINGS #######

//FPGA/PIO FAST I/O 
#define SAMPLE_CLK_FPGA 2
#define CLK_OUT 3
#define DATA_OUT 4
#define MUXSEL_0 5
#define MUXSEL_1 6
#define MUXSEL_2 7
#define IN_0_7 18
#define IN_8_15 19
#define IN_16_23 20

//OTHER INPUTS
#define ROT_A 9
#define ROT_B 8

//TFT MAPPINGS
#define D0 10
#define D1 11
#define D2 12
#define D3 13
#define D4 14
#define D5 15
#define D6 16
#define D7 17
#define DCX 27
#define WRX 22
#define RESET 28

#define RED    0b1111100000000000
#define GREEN  0b0000011111100000
#define BLUE   0b0000000000011111
#define WHITE  0b1111111111111111
#define PURPLE 0b1111100000011111
#define YELLOW 0b1111111111100000
#define CYAN   0b0000011111111111

//TIMERS
#define IO_READ_RATE -10 //ms

#endif