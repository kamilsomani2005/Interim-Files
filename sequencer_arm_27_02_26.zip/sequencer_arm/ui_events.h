#ifndef UI_EVENTS
#define UI_EVENTS
#include <vector>
#include "pico/multicore.h"

#include "page_enums.h"
#include "push_state_enums.h"
#include "defs.h"

#include "page_mixer.h"
#include "page_envelope.h"

#include "widgets.h"
#include "keyboard.h"
#include "rotary.h"

class ui_events 
{
    public:
        ui_events   (int *synth1_master_vol,
                     int *att1, int *dec1, int *sus1, int *rel1);
        void control_loop();
        signed int GLOBAL_ROT_LINK;
        signed int VARIABLE;
    private:
        page_mixer _page_mixer;
        page_envelope _page_env_synth1_v;



        rotary changeVar;
        keyboard objForKeystates;
        pageNames pagenames, pagenames_exit;
        rotaryPushState pushState;
        void decision();
        std::vector<widgets*> objArray;
        uint getCursorIndex();
        int WidgetsOnPage;

};

#endif