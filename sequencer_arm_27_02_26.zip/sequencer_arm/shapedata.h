#ifndef SHAPEDATA_H
#define SHAPEDATA_H
#include "pico/stdlib.h"
#include <vector>

#define NO_DEFINED_CHARS 26

const extern uint32_t a[64];
const extern uint32_t b[64];
const extern uint32_t c[64];
const extern uint32_t d[64];
const extern uint32_t e[64];
const extern uint32_t f[64];
const extern uint32_t g[64];
const extern uint32_t h[64];
const extern uint32_t i[64];
const extern uint32_t j[64];
const extern uint32_t k[64];
const extern uint32_t l[64];
const extern uint32_t m[64];
const extern uint32_t n[64];
const extern uint32_t o[64];
const extern uint32_t p[64];
const extern uint32_t q[64];
const extern uint32_t r[64];
const extern uint32_t s[64];
const extern uint32_t t[64];
const extern uint32_t u[64];
const extern uint32_t v[64];
const extern uint32_t w[64];
const extern uint32_t x[64];
const extern uint32_t y[64];
const extern uint32_t z[64];
extern std::vector<uint32_t> fader_sprite;
const extern uint32_t* char_ptr_arr[NO_DEFINED_CHARS];


#endif