#ifndef FADER_H
#define FADER_H
#include "screen.h"
#include <vector>


class fader : public screen
{
    public:
       void fader_create(uint32_t posx, uint32_t posy, int def_pos);
       void fader_show();
       void fader_update();
       void fader_hide();
       int var_to_fad_pos();
       int* get_var_ptr();
       int variable = 0;
    private:
       int scaled_fader_position_y = 0;
       uint32_t this_posx;
       uint32_t this_posy;
};

#endif 