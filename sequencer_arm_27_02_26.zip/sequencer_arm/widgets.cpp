#include "pico/stdlib.h"
#include "widgets.h"

//############## BUTTON FOR NAVIGATING #################//
widgets::widgets(int posx, int posy, std::string textstr, uint32_t colour, pageNames next_page) 
{
    widgets::textsprite.text_create(textstr, posx, posy, colour);
    widgettype = button;
    nextPage = next_page;
}

//############# GENERIC FADER ######################//
widgets::widgets(int posx, int posy, std::string textstr, uint32_t colour, int default_posn, int* var)
{
    widgets::textsprite.text_create(textstr, posx-10, posy+150, colour); 
    widgets::fadersprite.fader_create(posx, posy, default_posn);
    variableptr = var;
    widgettype = faderw;
}

//############# GENERIC SCROLL BUTTON ######################//
widgets::widgets(int posx, int posy, std::vector<std::string> strings, uint32_t colour, int* state)
{
}

void widgets::highlightText()
{
    textsprite.text_show_with_box_inv();
}

void widgets::n_highlightText()
{
    textsprite.text_show_with_box();
}

void widgets::showDefault()
{
    switch(widgettype)
    {
        case(button):
            textsprite.text_show_with_box();
            break;
        case(faderw):
            textsprite.text_show_with_box();
            fadersprite.variable = *variableptr;
            fadersprite.fader_update();
            break;
    }
}

void widgets::hide()
{
    switch(widgettype)
    {
        case(button):
            textsprite.text_hide_with_box();
            break;
        case(faderw):
            textsprite.text_hide_with_box();
            fadersprite.fader_hide();
            break;
    }
}

//default update function here

widgets::widgetProperties widgets::scanForChanges(rotaryPushState pushEvent)
{
    widgets::widgetProperties _temp; 

    switch(widgettype)
    {
        case(button):

            switch(pushEvent)
            {
                case(rotaryPushState::NO_CHANGE):
                    _temp.pageDecision = pageNames::_NOCHANGE;
                    break;
                case(rotaryPushState::ACTIVATED):
                    _temp.pageDecision = nextPage;
                    break;
                default:
                    _temp.pageDecision = pageNames::_NOCHANGE;
                    break;

            }
            _temp.enabScrolling = true;
            _temp.varPointer = nullptr;
        
        break;
                    
        case(faderw):

            static bool pushstate = false;
            switch(pushEvent)
            {
                case(rotaryPushState::NO_CHANGE):
                    break;
                case(rotaryPushState::ACTIVATED):
                    pushstate = !pushstate;
                    break;
            }
            switch(pushstate)
            {
                case(true):
                    _temp.varPointer = variableptr;
                    _temp.enabScrolling = false;
                    fadersprite.variable = *variableptr;
                    fadersprite.fader_update();
                    break;
                case(false):
                    _temp.varPointer = nullptr;
                    _temp.enabScrolling = true;
            }
            _temp.pageDecision = pageNames::_NOCHANGE;
        
        break;
    }

    return _temp;
    
}

