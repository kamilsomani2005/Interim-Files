#include <stdio.h>
#include <string>
#include "pico/stdlib.h"
#include "generator.h"
#include "hardware/gpio.h"
#include "math.h"
#include "hardware/pio.h"
#include "pi_tx.pio.h"
#include "pico/multicore.h"
#include "screen.h"
#include "defs.h"
#include "rotary.h"
#include "keyboard.h"
#include "envelope.h"
#include "ui_events.h"
#include "utils.h"

//timer_start = timer_time_us_64(timer0_hw);

vector<float> saw_table;
vector<int> saw_table_phases;
vector<float> square_table;
vector<int> square_table_phases;
vector<float> tri_table;
vector<int> tri_table_phases; 

//sound generation
generator synth1;
envelope adsr_synth1_v;

//IO instantiations
rotary ROTARY;
repeating_timer_t timer1;
keyboard keys;

//int buf_size;

PIO pio;
uint sm_tx;
uint offset_tx;

//need to figure out a better way to pass this into master_chn()

uint32_t master_chn(){
    float chn_1_out = adsr_synth1_v.getEnvCoef() * synth1.read_buffer() * returnLinearAuto(synth1.synth_master_volume); //float(synth1_master_volume/127);
    uint32_t digital_out = 32768*((chn_1_out+1.0)); 
    if(digital_out > 65535) {digital_out = 65535;}
    return digital_out;
}



void sample_handler(uint gpio, uint32_t events) {
    pio_sm_clear_fifos(pio, sm_tx);
    adsr_synth1_v.update(keys.atom_keyPress.load());
    adsr_synth1_v.calc_env_coef();
    pio_sm_put(pio, sm_tx, master_chn());
    ROTARY.rotary_handler();

}

void create_default_wavetables()
{
//square and saw wave default gen
for(int i=1; i<=MAX_ADDITIVE_OSC_NO; i++)
{
    saw_table.push_back(float(1.0/i));
    square_table_phases.push_back(0); 
    saw_table_phases.push_back(0);
    if(i%2 == 0)
    {
      square_table.push_back(0);
      tri_table.push_back(0);
    }
    else
    {
      square_table.push_back(float(1.0/i));
      tri_table.push_back(float(1.0/(i*i)));
    } 
}
//triangle wave default gen
for(int i=1; i<=MAX_ADDITIVE_OSC_NO; i++)
{
    if((i+1)%4 == 0)
    {
       tri_table_phases.push_back(88); 
    }
    else
    {
       tri_table_phases.push_back(0);
    }
}
}

void DEBUG_frequency_sweep_test()
{
    for(float i = 1.301; i < 4.301; i=i+0.035)
    {
        float logfreq = pow(10.0, i);
        int exp_sample_width = (int)round(float(SAMPLE_RATE-1)/logfreq);
        synth1.waveform(logfreq, saw_table, saw_table_phases);
        printf("freq: %f, expected sample width: %d \r\n", logfreq, exp_sample_width);
        sleep_ms(2000);
    }
}

bool io_handler(repeating_timer_t *rt)
{
    keys.get_keys_state();
    return true;
}

void side()
{

add_repeating_timer_ms(IO_READ_RATE, io_handler, NULL, &timer1);
irq_set_priority(TIMER0_IRQ_1, 1);
keys.init_gpio();

    while (true){
        synth1.waveform(keys.last_pressed, saw_table, saw_table_phases);
        
    }
}


int main()
{

stdio_init_all();
create_default_wavetables();

screen tft;
ROTARY.setupGPIO();
tft.init();

gpio_init(SAMPLE_CLK_FPGA);
gpio_set_dir(SAMPLE_CLK_FPGA, false);

bool success_tx_pio = pio_claim_free_sm_and_add_program_for_gpio_range(&pi_tx_program, &pio, &sm_tx, &offset_tx, CLK_OUT, 2, true);
pi_tx_program_init(pio, sm_tx, offset_tx, CLK_OUT, DATA_OUT);
gpio_set_irq_enabled_with_callback(SAMPLE_CLK_FPGA, GPIO_IRQ_EDGE_RISE, true, &sample_handler);
irq_set_priority(IO_IRQ_BANK0, 0);

multicore_launch_core1(side); //move this down perhaps?

//&adsr_synth1_v.att_smp, &adsr_synth1_v.dec_smp, &adsr_synth1_v.flt_int, &adsr_synth1_v.rel_smp
ui_events UI(&synth1.synth_master_volume,
             &adsr_synth1_v.att_link, &adsr_synth1_v.dec_link, &adsr_synth1_v.flt_int, &adsr_synth1_v.rel_link);

ROTARY.pointToSelector(&UI.GLOBAL_ROT_LINK);


    while (true){
        //adsr calc here
        UI.control_loop();
        sleep_ms(50);
        adsr_synth1_v.calcNewParams();
        //printf("val: \r\n");
    }
}






