#ifndef PAGE_ENUMS_H
#define PAGE_ENUMS_H

enum class pageNames
{
    _NOCHANGE,
    MIXER,
    SYNTH1_GENERATOR,
    SYNTH1_ENVELOPE

};

#endif