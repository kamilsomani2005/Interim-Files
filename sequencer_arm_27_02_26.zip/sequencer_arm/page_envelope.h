#ifndef PAGE_ENVELOPE_H
#define PAGE_ENVELOPE_H
#include "widgets.h"
#include "screen.h"
#include "page_enums.h"
#include "visual_defs.h"
#include <vector>

class page_envelope
{
    public:
        page_envelope(int *att, int *dec, int *sus, int *rel);
        std::vector<widgets*> showAll();
        void hideAll();
        int returnNumWidgets();
    private:
        widgets* attack;
        widgets* decay;
        widgets* sustain;
        widgets* release;
        text STATIC_envelope;
        widgets* back_button;
        

};

#endif 