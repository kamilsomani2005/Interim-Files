#ifndef UTILS_H
#define UTILS_H

extern float logTable[128];

void boundVariableMinZero(int &param);

float returnLinearAuto(int &param);

float returnEnvSampleLogAuto(int &param);

int returnEnvSampleLog(int param);

#endif