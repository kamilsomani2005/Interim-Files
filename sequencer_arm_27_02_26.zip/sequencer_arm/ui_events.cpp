#include "pico/stdlib.h"
#include "ui_events.h"


ui_events::ui_events(int *synth1_master_vol, 
                     int *att1, int *dec1, int *sus1, int *rel1)
    :_page_mixer(synth1_master_vol),_page_env_synth1_v(att1, dec1, sus1, rel1)
{
    
    pagenames = pageNames::MIXER;
    GLOBAL_ROT_LINK = 0;
}

void ui_events::control_loop()
{
    
    switch(pagenames)
    {
        case(pageNames::_NOCHANGE):
            decision();
            if(pagenames != pageNames::_NOCHANGE){
                switch(pagenames_exit)
                {
                    case(pageNames::MIXER):
                        _page_mixer.hideAll();
                        break;
                    case(pageNames::SYNTH1_ENVELOPE):
                        _page_env_synth1_v.hideAll();
                        break;
                    default:
                        break;
                }
            }
            break;
        case(pageNames::MIXER):
            objArray = _page_mixer.showAll();
            WidgetsOnPage = _page_mixer.returnNumWidgets();
            pagenames = pageNames::_NOCHANGE;
            pagenames_exit = pageNames::MIXER;
            break;
        case(pageNames::SYNTH1_ENVELOPE):
            objArray = _page_env_synth1_v.showAll();
            WidgetsOnPage = _page_env_synth1_v.returnNumWidgets();
            pagenames = pageNames::_NOCHANGE;
            pagenames_exit = pageNames::SYNTH1_ENVELOPE;
            break;
    }

}

void ui_events::decision() //return a page enum
{
    uint currCursor = getCursorIndex();
    objArray[currCursor]->highlightText();
    for(int scanThruIndex=0; scanThruIndex<WidgetsOnPage; scanThruIndex++){
        //perhaps include an update function here (coded in widgets) to update moving sprites such as volume meters, oscilloscope etc.
        if(scanThruIndex!=currCursor){
            objArray[scanThruIndex]->n_highlightText();
        }
    }
    widgets::widgetProperties _tmp = (objArray[currCursor]->scanForChanges(objForKeystates.get_rotary_button_state()));
    pagenames = _tmp.pageDecision;
    changeVar.pointToVariable(&GLOBAL_ROT_LINK, _tmp.varPointer, _tmp.enabScrolling);

}

uint ui_events::getCursorIndex()
{
    if(GLOBAL_ROT_LINK < 0){
        GLOBAL_ROT_LINK = 0;
    }
    else{
        GLOBAL_ROT_LINK = GLOBAL_ROT_LINK%WidgetsOnPage;
    }
    return GLOBAL_ROT_LINK;
}


