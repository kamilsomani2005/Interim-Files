#ifndef SCREEN_H
#define SCREEN_H
#include "defs.h"
#include "shapedata.h"
#include <vector>

class screen
{
    public:
        //screen();
        void init();
        void def_wr_area(uint32_t posx, uint32_t posy, uint32_t sizx, uint32_t sizy);
        void wr_seq_from_arr32(std::vector<uint32_t>* input_buffer, int sizeof_buf, unsigned char CM_H, unsigned char CM_L);
        void wr_seq_from_arr32_orig_colors(std::vector<uint32_t>* input_buffer, int sizeof_buf);
        void wr_seq_from_arr32_inv(std::vector<uint32_t>* input_buffer, int sizeof_buf, unsigned char CM_H, unsigned char CM_L);
        void erase_area(uint32_t posx, uint32_t posy, uint32_t lenx, uint32_t leny);
        void hline(uint32_t posx, uint32_t posy, int length);
        void vline(uint32_t posx, uint32_t posy, int length);
        void write_cmd(uint32_t cmd);
        void write_data(uint32_t data);
        //void screen::write_from_array(char &buf, uint32_t posx, uint32_t posy, uint32_t sizx, uint32_t sizy);
        void DEBUG_make_boxes();
    private:
        
        
};

#endif