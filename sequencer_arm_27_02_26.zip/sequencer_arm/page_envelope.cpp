#include "pico/stdlib.h"
#include "page_envelope.h"
#include "widgets.h"

#define WIDGETS_ON_PAGE 5

page_envelope::page_envelope(int *att, int *dec, int *sus, int*rel)
{
    STATIC_envelope.text_create("envelope", BASE_POSX, BASE_POSY, WHITE);
    back_button = new widgets(319-34, BASE_POSY, "back", RED, pageNames::MIXER);
    attack = new widgets(BASE_POSX+15, BASE_POSY+TEXTBOX_WIDTH_Y*6, "attack", WHITE, 0, att);
    decay = new widgets(BASE_POSX+15+INSTR_SPACINGS, BASE_POSY+TEXTBOX_WIDTH_Y*6, "decay", WHITE, 0, dec);
    sustain = new widgets(BASE_POSX+15+INSTR_SPACINGS*2, BASE_POSY+TEXTBOX_WIDTH_Y*6, "sustain", WHITE, 0, sus);
    release = new widgets(BASE_POSX+15+INSTR_SPACINGS*3, BASE_POSY+TEXTBOX_WIDTH_Y*6, "release", WHITE, 0, rel);
    //load in member highlight/n_highlight functions into a vector here for selector funct.in ui
}

std::vector<widgets*> page_envelope::showAll()
{
    std::vector<widgets*> objArray;

    attack->showDefault();
    decay->showDefault();
    sustain->showDefault();
    release->showDefault();
    back_button->showDefault();

    STATIC_envelope.text_show();

    objArray.push_back(attack);
    objArray.push_back(decay);
    objArray.push_back(sustain);
    objArray.push_back(release);
    objArray.push_back(back_button);

    return objArray;

}

void page_envelope::hideAll()
{
    attack->hide();
    decay->hide();
    sustain->hide();
    release->hide();
    back_button->hide();
    STATIC_envelope.text_hide();
}

int page_envelope::returnNumWidgets()
{
    return WIDGETS_ON_PAGE;
}