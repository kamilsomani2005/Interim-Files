#include "pico/stdlib.h"
#include "rotary.h"
#include "defs.h"
#include "hardware/gpio.h"


void rotary::setupGPIO()
{
    gpio_init(ROT_A);
    gpio_init(ROT_B);
    gpio_set_dir(ROT_A, false);
    gpio_set_dir(ROT_B, false);
    state = getCaseFromGPIO();
}

void rotary::rotary_handler()
{
    switch(state)
    {
        case(0):    //00
            state = getCaseFromGPIO();
            if(state == 1){
                (*var)++;
            }
            else if(state == 3){
                (*var)--;
            }
            break;
        case(1):    //10
            state = getCaseFromGPIO();
            break;
        case(2):    //11
            state = getCaseFromGPIO();
            if(state == 3){
                (*var)++;
            }
            else if(state == 1){
                (*var)--;
            }
            break;
        case(3):    //01
            state = getCaseFromGPIO();
            break;
        default:    //??
            state = getCaseFromGPIO();
            break;
    }
    

}

void rotary::pointToSelector(int *var_to_modify)
{
    var = var_to_modify;    
}

void rotary::pointToVariable(int *scrollpos_to_modify, int *var_to_modify, bool enabScrolling) //potentially overload this func with atomic<int*>
{

    if(enabScrolling){
        var = scrollpos_to_modify;
    }
    else{
        var = var_to_modify;
    }
       
    
}

int rotary::getCaseFromGPIO()
{
    bool A = gpio_get(ROT_A);
    bool B = gpio_get(ROT_B);
    if(!A && !B){return 0;}
    else if(A && !B){return 1;}
    else if(A && B){return 2;}
    else if(!A && B){return 3;}
    else{return 4;}
    
}
