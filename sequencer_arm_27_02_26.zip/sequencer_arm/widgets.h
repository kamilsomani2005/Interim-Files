#ifndef WIDGETS_H
#define WIDGETS_H
#include "text.h"
#include "fader.h"
#include "page_enums.h"
#include "push_state_enums.h"
#include <string>
#include <vector>

class widgets
{
    enum widgetType
    {
        button, faderw, scrollbutton
    };
    public:
        struct widgetProperties{ 
            pageNames pageDecision;
            int *varPointer;
            bool enabScrolling;
        };
        widgets(int posx, int posy, std::string textstr, uint32_t colour, pageNames next_page); //button ctor
        widgets(int posx, int posy, std::string textstr, uint32_t colour, int default_posn, int* var); //fader ctor
        void highlightText();
        void n_highlightText();
        widgetProperties scanForChanges(rotaryPushState pushState);
        void showDefault ();
        void hide();
    private:
        pageNames nextPage;
        widgetType widgettype;
        text textsprite;
        fader fadersprite;
        int* variableptr;

};

#endif