#ifndef VISUAL_DEFS_H
#define VISUAL_DEFS_H

#define BASE_POSX 4
#define BASE_POSY 4
#define TEXTBOX_WIDTH_Y 11
#define INSTR_SPACINGS 80

#endif