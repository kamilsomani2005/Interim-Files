#include <stdio.h>
#include <string>
#include "pico/stdlib.h"
#include "text.h"
#include "shapedata.h"
#include <vector>

void text::text_create(std::string text, uint32_t posx, uint32_t posy, uint32_t colourmask)
{
   len_txt = text.size(); 
   this_posx = posx;
   this_posy = posy;
   for(int vline_index=0; vline_index<8; vline_index++)
   {
        for(int txt_index=0; txt_index<len_txt; txt_index++)
        {
            char character_in_str = text[txt_index];
            for(int hline_index=0; hline_index<8; hline_index++)
            {
                buf.push_back(char_ptr_arr[character_in_str-97][hline_index+(8*vline_index)]);
            }
        }
   }
   sizeof_buffer = buf.size();
   CM_H = colourmask >> 8;
   CM_L = colourmask;

   
   
}

void text::text_show()
{
    def_wr_area(this_posx, this_posy, len_txt*8, 8);
    wr_seq_from_arr32(&buf, sizeof_buffer, CM_H, CM_L);

}

// OLD FUNCTION NOW USING ONE DEFINED IN SCREEN_CPP
/*  
void text::text_hide()
{
    def_wr_area(this_posx, this_posy, len_txt*8, 8);
    for(int buf_index =0; buf_index<sizeof_buffer; buf_index++)
    {
        write_data(0x00);
        write_data(0x00);
    }
}
*/

void text::text_hide()
{
    erase_area(this_posx, this_posy, len_txt*8, 8);
}

void text::text_show_with_box()
{
    hline(this_posx, this_posy, (len_txt*8)+2);
    hline(this_posx, this_posy+9, (len_txt*8)+2);
    vline(this_posx, this_posy, 10);
    vline(this_posx+((len_txt*8)+1), this_posy, 10);
    def_wr_area(this_posx+1, this_posy+1, len_txt*8, 8);
    wr_seq_from_arr32(&buf, sizeof_buffer, CM_H, CM_L);

}

void text::text_hide_with_box()
{
    def_wr_area(this_posx, this_posy, (len_txt*8)+2, 10);
    for(int buf_index =0; buf_index<(sizeof_buffer+(len_txt*16)+24); buf_index++)
    {
        write_data(0x00);
        write_data(0x00);
    }

}

void text::text_show_with_box_inv()
{
    hline(this_posx, this_posy, (len_txt*8)+2);
    hline(this_posx, this_posy+9, (len_txt*8)+2);
    vline(this_posx, this_posy, 10);
    vline(this_posx+((len_txt*8)+1), this_posy, 10);
    def_wr_area(this_posx+1, this_posy+1, len_txt*8, 8);
    wr_seq_from_arr32_inv(&buf, sizeof_buffer, CM_H, CM_L);
    
}