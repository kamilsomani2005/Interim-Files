#ifndef OSCILLATOR_H
#define OSCILLATOR_H
#include "defs.h"

class oscillator
{
    public:
        double get_sin(int base_freq, int phi);
        oscillator();
        static void init_sin();
    private:
        unsigned int index;
        
};

#endif