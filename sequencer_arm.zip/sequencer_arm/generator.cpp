#include "generator.h"
#include <stdio.h>
#include <cmath>
#include "pico/stdlib.h"
#include "pico/double.h"
#include "array"

generator::generator()
{
    sigFinished_calc = false;
    buffer[0] = 0.0;
    rd_buffer_start_point = 0;
    wr_buffer_start_point = 1;
    sample_width_for_prev_note = 1;
    index_offset = 0;
}

int generator::waveform(float base_note, vector<double> &ampl_table, vector<int> &phase_table, double synth_vol)
{
    int timer_start = timer_time_us_64(timer0_hw);
    double step;
    //TODO: this should run for all note freqs at initialisation to create a table
    //SLOW- ARRAYS CREATED EACH TIME AND DESTROYED
    //of sample widths that can be passed in as pointer
    sample_width_for_note = (int)round(float(SAMPLE_RATE-1)/base_note); 
    double this_note_sin_table[sample_width_for_note];
    for(int sample=0; sample<sample_width_for_note; sample++)
    {
        step = 360*(double(sample)/sample_width_for_note);
        this_note_sin_table[sample] = (sin(step*PI/180));
    }
    // ###################
    //DEBUG
    //printf("\r\n ---------- WRITE STEP ANALYSIS \r\n ---------------");
    //DEBUG
    for(int sample = 0; sample<sample_width_for_note; sample++)
    {
        wraparound_index = (sample+wr_buffer_start_point)%(BUF_SIZE);
        buffer[wraparound_index] = this_note_sin_table[sample];
    }
    for(int harmonic = 2; harmonic<=MAX_ADDITIVE_OSC_NO; harmonic++)
    {
        harmonic_index = 0 + phase_table[harmonic-1];
        for(int sample=0; sample<sample_width_for_note; sample++)
        {
            harmonic_index = harmonic_index+harmonic;
            harmonic_index = harmonic_index % sample_width_for_note;
            wraparound_index = (sample+wr_buffer_start_point)%(BUF_SIZE);
            //DEBUG
            //printf("index for writing: %d \r\n", wraparound_index);
            //DEBUG
            buffer[wraparound_index] = buffer[wraparound_index]+this_note_sin_table[harmonic_index]*(ampl_table[harmonic-1]);
        }
    }
    /*
    sleep_ms(5000);
    for(int sample=0; sample<sample_width_for_note; sample++)
    {
        printf(">index:%d, value:%f, computation_time%d\r\n", sample, waveform_final[sample], timer_end-timer_start);
    }
    */
    sample_width_for_prev_note = sample_width_for_note;
    rd_buffer_start_point = wr_buffer_start_point; 
    index_offset = 0;
    wr_buffer_start_point = (wr_buffer_start_point+(sample_width_for_note-1))%(BUF_SIZE);
    sigFinished_calc = true;
    int timer_end = timer_time_us_64(timer0_hw);
    return timer_end-timer_start;
}

double generator::read_buffer()
{
    index = (rd_buffer_start_point + (index_offset%sample_width_for_prev_note))%(BUF_SIZE);
    index_offset ++;
    return buffer[index];
}

void generator::DEBUG_get_buffer_stats()
{
    static int step = 1;
    printf("\r\n ----Step: %d -------- \r\n", step);
    printf("Sample width reading: %d \r\n", sample_width_for_prev_note);
    printf("Sample width writing: %d \r\n", sample_width_for_note);
    printf("READ index start: %d \r\n", rd_buffer_start_point);
    printf("WRITE index start: %d \r\n", wr_buffer_start_point);
    printf("\r\n ---------------------- \r\n");
    step++;
}

void generator::DEBUG_read_buffer()
{
    printf("\r\n--------- STEP ANALYSIS ------------\r\n ");
    int DEBUG_index;
    for(int DEBUG_index_offset = 0; DEBUG_index_offset < 250; DEBUG_index_offset++)
    {
        DEBUG_index = (rd_buffer_start_point + (DEBUG_index_offset%sample_width_for_prev_note))%(BUF_SIZE);
        printf(" --- index: %d ----- \r\n", DEBUG_index);
    }

}