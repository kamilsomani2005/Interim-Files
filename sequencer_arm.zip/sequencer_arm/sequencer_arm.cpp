#include <stdio.h>
#include <string>
#include "pico/stdlib.h"
#include "generator.h"
#include "oscillator.h"
#include "hardware/gpio.h"
#include "math.h"
#include "hardware/pio.h"
#include "pi_tx.pio.h"
#include "button_serial.pio.h"
#include "pico/multicore.h"

//timer_start = timer_time_us_64(timer0_hw);

#define SAMPLE_CLK_FPGA 2
#define CLK_OUT 3
#define DATA_OUT 4
#define BTN_IRQ 5
#define DATA_IN 6
#define CLK_OUT_BTN 7
//#define DEBUG_MODE

double bit_depth_med_val = pow(2, BIT_DEPTH-1.0);
uint32_t bit_depth_max_val = pow(2, BIT_DEPTH)-1;

vector<double> saw_table;
vector<int> saw_table_phases;
vector<double> square_table;
vector<int> square_table_phases;
vector<double> tri_table;
vector<int> tri_table_phases; 

int timer_start, timer_end = 0;
generator synth1;

int buf_size;

PIO pio;
uint sm_tx, sm_rx;
uint offset_tx, offset_rx;

uint32_t master_chn(double vol_master){
    uint32_t digital_out = 32768*((vol_master*synth1.read_buffer())+1.0);
    if(digital_out > 65535) {digital_out = 65535;}
    return digital_out;
}

void sample_handler(uint gpio, uint32_t events) {
    pio_sm_clear_fifos(pio, sm_tx);
    pio_sm_put(pio, sm_tx, master_chn(1.0));
}

void button_handler(uint gpio, uint32_t events) {
    pio_sm_clear_fifos(pio, sm_rx);
    pio_sm_set_enabled(pio, sm_rx, true);
    int data = pio_sm_get_blocking(pio, sm_rx);
    pio_sm_set_enabled(pio, sm_rx, false);
    //printf("Bitstream: %d\n\r",  data);

}

void create_default_wavetables()
{
//square and saw wave default gen
for(int i=1; i<=MAX_ADDITIVE_OSC_NO; i++)
{
    saw_table.push_back(double(1.0/i));
    square_table_phases.push_back(0); 
    saw_table_phases.push_back(0);
    if(i%2 == 0)
    {
      square_table.push_back(0);
      tri_table.push_back(0);
    }
    else
    {
      square_table.push_back(double(1.0/i));
      tri_table.push_back(double(1.0/(i*i)));
    } 
}
//triangle wave default gen
for(int i=1; i<=MAX_ADDITIVE_OSC_NO; i++)
{
    if((i+1)%4 == 0)
    {
       tri_table_phases.push_back(88); 
    }
    else
    {
       tri_table_phases.push_back(0);
    }
}
}

void DEBUG_frequency_sweep_test()
{
    for(float i = 1.301; i < 4.301; i=i+0.035)
    {
        float logfreq = pow(10.0, i);
        int exp_sample_width = (int)round(float(SAMPLE_RATE-1)/logfreq);
        synth1.waveform(logfreq, saw_table, saw_table_phases, 0.2);
        printf("freq: %f, expected sample width: %d \r\n", logfreq, exp_sample_width);
        sleep_ms(2000);
    }
}

void DEBUG_single_tone(int freq)
{
    synth1.waveform(freq, saw_table, saw_table_phases, 0.2);
}

void side()
{

gpio_init(BTN_IRQ);
bool success_rx_pio = pio_claim_free_sm_and_add_program_for_gpio_range(&button_serial_program, &pio, &sm_rx, &offset_rx, DATA_IN, 2, true);
button_serial_program_init(pio, sm_rx, offset_rx, CLK_OUT_BTN, DATA_IN);

gpio_set_irq_enabled_with_callback(BTN_IRQ, GPIO_IRQ_EDGE_FALL | GPIO_IRQ_EDGE_RISE, true, &button_handler);

    while (true){
        
    }
}


int main()
{


stdio_init_all();
oscillator::init_sin();
create_default_wavetables();

gpio_init(SAMPLE_CLK_FPGA);
multicore_launch_core1(side);

bool success_tx_pio = pio_claim_free_sm_and_add_program_for_gpio_range(&pi_tx_program, &pio, &sm_tx, &offset_tx, CLK_OUT, 2, true);
pi_tx_program_init(pio, sm_tx, offset_tx, CLK_OUT, DATA_OUT);

gpio_set_irq_enabled_with_callback(SAMPLE_CLK_FPGA, GPIO_IRQ_EDGE_RISE, true, &sample_handler);
uint32_t __TEST_BUF_SER;
int buf_index = 0;
    DEBUG_single_tone(1000);
    while (true){
        //printf(">Value: %f, Computation time: %d\r\n", synth1_out, timer_end-timer_start);
        /*
        int timer_start = timer_time_us_64(timer0_hw);
        __TEST_BUF_SER = master_chn(0.5, buffer_1, buf_size);
        int timer_end = timer_time_us_64(timer0_hw);
        printf(">val: %d, comp_time: %d, index: %d \r\n", __TEST_BUF_SER, timer_end - timer_start, buf_index);
        buf_index++;
        sleep_us(20);
        */
        //DEBUG_frequency_sweep_test();
        
    }
}






