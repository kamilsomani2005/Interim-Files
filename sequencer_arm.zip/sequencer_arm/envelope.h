#ifndef ENVELOPE_H
#define ENVELOPE_H

class envelope
{
    public:
        double get_amplitude(int a, int d, int s, int r);
};

#endif