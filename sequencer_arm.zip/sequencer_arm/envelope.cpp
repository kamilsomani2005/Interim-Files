#include "envelope.h"
#include <stdio.h>
#include "pico/stdlib.h"
#include "defs.h"

/*
double envelope::get_amplitude(int a, int d, int s, int r)
{
    int state = 1;
    switch (state)
    {
        case 1: //attack
            for(int index = 0; index < ; index++)
            {
                
            }

    }
}
    */