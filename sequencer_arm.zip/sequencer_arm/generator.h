#ifndef GENERATOR_H
#define GENERATOR_H
#define BUF_SIZE 4000
#include "oscillator.h"
#include <vector>
using std::vector;

class generator
{
    public:
        //returns computation time
        int waveform(float base_note, vector<double> &ampl_table, vector<int> &phase_table, double synth_vol);
        double read_buffer();
        void DEBUG_read_buffer();
        void DEBUG_get_buffer_stats();
        generator();
        bool sigFinished_calc;
    private:
        int wraparound_index;
        double buffer[BUF_SIZE];
        int wr_buffer_start_point;
        int rd_buffer_start_point;
        int harmonic_index;
        int phase;
        int sample_width_for_note;
        int sample_width_for_prev_note;
        int index;
        long long index_offset;
        vector<oscillator*> oscTable;
        
};

#endif