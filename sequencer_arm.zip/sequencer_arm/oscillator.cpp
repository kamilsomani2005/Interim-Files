#include <stdio.h>
#include "pico/stdlib.h"
#include "oscillator.h"
#include <math.h>

static double sin_table[SAMPLE_RATE];

oscillator::oscillator()
{
    index = 0;
};

double oscillator::get_sin(int base_freq, int phi) //phi is phase in samples
{
    index = index + base_freq;
    if(index > SAMPLE_RATE-1)
    {
        index = index-SAMPLE_RATE-1;
    }
    return sin_table[index + phi]; 
};

void oscillator::init_sin()
{
    double raw_sin;
    double step;
    signed int sin_16;
    unsigned int no_bits = pow(2.0, BIT_DEPTH-1);
    
    for(int sin_index = 0; sin_index < SAMPLE_RATE; sin_index ++)
    {
        step = 360*(double(sin_index)/SAMPLE_RATE-1);
        raw_sin = sin(step*PI/180);
        //sin_16 = int(raw_sin*no_bits);
        sin_table[sin_index] = raw_sin;
    };
};
