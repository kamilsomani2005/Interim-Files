#ifndef DEFS_H
#define DEFS_H

#define SAMPLE_RATE 39062
#define SAMPLE_PERIOD_US 25
#define BIT_DEPTH 16.0
#define PI 3.14159265
#define MAX_ADDITIVE_OSC_NO 1

#endif